"""
Edo Tensei's models and textures (my own designs, drawn by client/EdoTenseiRenderer.java and client/fx/FxEdo.java):

  assets/shinobiarts/meshes/edo_coffin.bin           the coffin the soul comes back in: an upright wooden coffin, 1 block
                                                     wide and 2.3 tall, standing on y = 0 with its lid facing +z.
                                                     Group 0 is the coffin, group 1 its lid, stored relative to its hinge
                                                     (its bottom front edge; FxEdo.HINGE_Y / HINGE_Z say where that is) so
                                                     it can fall forward flat on the ground.
  textures/entity/edo_tensei/coffin.png              its texture

The coffin comes from tools/source_art/edo_coffin.glb: "Naruto - Ataud Edo Tensei" by GremorySaiyan
(https://sketchfab.com/3d-models/naruto-ataud-edo-tensei-768889e3658d49a6a5a71890c0704f79), licensed CC-BY-4.0
(http://creativecommons.org/licenses/by/4.0/); converted to the mod's mesh format (rotated upright, scaled to 2.3
blocks, the lid split off on its hinge, texture resized). Without that file the old box coffin below is built instead.
  textures/entity/edo_tensei/souls/soul_*.png        skins for nameless souls (my own designs: a cloaked wanderer, a
                                                     village guard, a swordsman)
  textures/entity/edo_tensei/cracks.png              laid over the reanimated body (player skin layout, 4x finer): the
                                                     cracks of a body made of ash and dust, and black whites of the eyes

Run: python3 tools/make_edo_tensei.py   (needs numpy and Pillow)
"""
import math
import os
import random
import struct

import numpy as np
from PIL import Image, ImageDraw, ImageFilter

HERE = os.path.dirname(os.path.abspath(__file__))
ASSETS = os.path.join(HERE, "..", "src", "main", "resources", "assets", "shinobiarts")


def out(*parts):
    p = os.path.join(ASSETS, *parts)
    os.makedirs(os.path.dirname(p), exist_ok=True)
    return p


# ------------------------------------------------------------------ the coffin mesh

# where each kind of face takes its texture from (u0, v0, u1, v1)
WOOD = (0.0, 0.0, 0.5, 0.75)
INNER = (0.0, 0.75, 0.5, 1.0)
LID = (0.5, 0.0, 1.0, 1.0)
EDGE = (0.0, 0.0, 0.5, 0.1)

FACES = {  # normal, the 4 corners as (x, y, z) picks of (lo, hi) per axis, counter-clockwise from outside
    "+x": ((1, 0, 0), [(1, 0, 1), (1, 0, 0), (1, 1, 0), (1, 1, 1)]),
    "-x": ((-1, 0, 0), [(0, 0, 0), (0, 0, 1), (0, 1, 1), (0, 1, 0)]),
    "+y": ((0, 1, 0), [(0, 1, 1), (1, 1, 1), (1, 1, 0), (0, 1, 0)]),
    "-y": ((0, -1, 0), [(0, 0, 0), (1, 0, 0), (1, 0, 1), (0, 0, 1)]),
    "+z": ((0, 0, 1), [(0, 0, 1), (1, 0, 1), (1, 1, 1), (0, 1, 1)]),
    "-z": ((0, 0, -1), [(1, 0, 0), (0, 0, 0), (0, 1, 0), (1, 1, 0)]),
}


def box(tris, lo, hi, regions, skip=()):
    """A box from lo to hi; regions maps a face ("+x"...) to its texture rect, or "*" for the rest."""
    for face, (n, corners) in FACES.items():
        if face in skip:
            continue
        rect = regions.get(face, regions.get("*", WOOD))
        P = [tuple(lo[i] if c[i] == 0 else hi[i] for i in range(3)) for c in corners]
        # v runs up the coffin (or along z on the top and bottom); the grain keeps its scale
        axes = [i for i in range(3) if n[i] == 0]
        ua, va = ([a for a in axes if a != 1][0], 1) if 1 in axes else (0, 2)
        su = 1.0 if rect is LID else min(1.0, (hi[ua] - lo[ua]) / 1.2)
        sv = 1.0 if rect is LID else min(1.0, (hi[va] - lo[va]) / 2.4)
        UV = [(rect[0] + (rect[2] - rect[0]) * c[ua] * su, rect[3] - (rect[3] - rect[1]) * c[va] * sv) for c in corners]
        for i, j, k in ((0, 1, 2), (0, 2, 3)):
            tris.append(((P[i], P[j], P[k]), (UV[i], UV[j], UV[k]), (n, n, n)))


W, H, D, T = 1.0, 2.3, 0.78, 0.075


def coffin():
    body, lid = [], []
    x0, x1, z0, z1 = -W / 2, W / 2, -D / 2, D / 2
    # the back, the sides, the roof and the floor (the inner faces dark)
    box(body, (x0, 0.12, z0), (x1, H - 0.14, z0 + T), {"+z": INNER, "*": WOOD})
    box(body, (x0, 0.12, z0), (x0 + T, H - 0.14, z1), {"+x": INNER, "*": WOOD})
    box(body, (x1 - T, 0.12, z0), (x1, H - 0.14, z1), {"-x": INNER, "*": WOOD})
    box(body, (x0, 0.12, z0), (x1, 0.12 + T, z1), {"+y": INNER, "*": WOOD})
    box(body, (x0, H - 0.14 - T, z0), (x1, H - 0.14, z1), {"-y": INNER, "*": WOOD})
    # a heavier crown on top and a plinth underneath, both a little wider than the body
    box(body, (x0 - 0.07, H - 0.14, z0 - 0.07), (x1 + 0.07, H - 0.04, z1 + 0.07), {"*": EDGE})
    box(body, (x0 - 0.03, H - 0.04, z0 - 0.03), (x1 + 0.03, H, z1 + 0.03), {"*": EDGE})
    box(body, (x0 - 0.06, 0.0, z0 - 0.06), (x1 + 0.06, 0.12, z1 + 0.06), {"*": EDGE})
    # two iron bands round the back and sides
    for y in (0.55, H - 0.6):
        iron = {"*": (0.0, 0.0, 0.02, 0.02)}
        box(body, (x0 - 0.012, y, z0 - 0.012), (x1 + 0.012, y + 0.06, z0), iron)
        box(body, (x0 - 0.012, y, z0), (x0, y + 0.06, z1 - 0.02), iron)
        box(body, (x1, y, z0), (x1 + 0.012, y + 0.06, z1 - 0.02), iron)
    # the lid, hinged on its bottom front edge (y = 0, z = 0 here), lying against the front when shut
    lw, lh = W - 0.02, H - 0.28
    box(lid, (-lw / 2, 0.0, -T), (lw / 2, lh, 0.0), {"+z": LID, "-z": INNER, "*": WOOD})
    return body, lid


def write_mesh(path, groups):
    with open(path, "wb") as f:
        f.write(struct.pack(">i", len(groups)))
        for tex, opacity, tris in groups:
            f.write(struct.pack(">ifi", tex, opacity, len(tris)))
            for P, UV, N in tris:
                for k in range(3):
                    f.write(struct.pack(">8f", *P[k], *UV[k], *N[k]))


# ------------------------------------------------------------------ the coffin's texture

def wood(w, h, base, seed, planks=4):
    """Old dark planks: vertical boards, fine grain, a few knots, darker at the joins."""
    rnd = np.random.default_rng(seed)
    y = np.linspace(0, 1, h)[:, None]
    x = np.linspace(0, 1, w)[None, :]
    grain = np.zeros((h, w))
    for k in range(6):
        f = 6 + k * 9
        grain += np.sin((x * f * 6 + np.sin(y * (3 + k) * math.pi + k) * (0.6 + k * 0.2)) * math.pi) / (k + 1)
    grain = (grain - grain.min()) / (np.ptp(grain) + 1e-9)
    noise = rnd.normal(0, 1, (h, w))
    img = np.zeros((h, w, 3))
    for c in range(3):
        img[..., c] = base[c] * (0.78 + 0.32 * grain + 0.05 * noise)
    pw = w / planks
    for i in range(1, planks):
        xi = int(i * pw)
        img[:, max(0, xi - 1):xi + 1] *= 0.45
    for _ in range(3):  # knots
        cx, cy, r = rnd.uniform(0, w), rnd.uniform(0, h), rnd.uniform(2, 4.5)
        yy, xx = np.mgrid[0:h, 0:w]
        d = np.sqrt((xx - cx) ** 2 + ((yy - cy) * 0.6) ** 2)
        img *= (1 - 0.35 * np.exp(-(d / r) ** 2))[..., None]
    return np.clip(img, 0, 255)


def coffin_texture(size=256):
    img = np.zeros((size, size, 4))
    half = size // 2
    oh = int(size * 0.75)
    img[:oh, :half, :3] = wood(half, oh, (92, 72, 56), 3)
    img[oh:, :half, :3] = wood(half, size - oh, (40, 30, 24), 5)
    lid = wood(half, size, (96, 75, 58), 7, planks=3)
    img[:, half:, :3] = lid
    img[..., 3] = 255
    # the iron bands' corner of the atlas
    img[:5, :5, :3] = (58, 58, 62)
    im = Image.fromarray(img.astype(np.uint8), "RGBA")
    d = ImageDraw.Draw(im)
    # the lid: a carved frame, then the paper seal pasted down its middle
    fx0, fx1 = half + 9, size - 10
    d.rectangle((fx0, 8, fx1, size - 9), outline=(48, 36, 28, 255), width=3)
    d.rectangle((fx0 + 5, 13, fx1 - 5, size - 14), outline=(120, 96, 74, 255), width=1)
    sx0, sx1 = half + half // 2 - 15, half + half // 2 + 15
    sy0, sy1 = 34, 176
    d.rectangle((sx0, sy0, sx1, sy1), fill=(226, 216, 190, 255))
    d.rectangle((sx0 + 2, sy0 + 2, sx1 - 2, sy1 - 2), outline=(150, 40, 34, 255), width=1)
    # brush strokes on the seal: my own marks, not writing
    rnd = random.Random(11)
    cx = (sx0 + sx1) / 2
    y = sy0 + 12
    for glyph in range(4):
        for s in range(rnd.randint(3, 5)):
            a = (cx + rnd.uniform(-9, 9), y + rnd.uniform(0, 18))
            b = (a[0] + rnd.uniform(-8, 8), a[1] + rnd.uniform(2, 10))
            d.line((a, b), fill=(22, 18, 16, 255), width=rnd.choice((2, 3)))
        d.line(((cx - 9, y + 20), (cx + 9, y + 20)), fill=(22, 18, 16, 255), width=2)
        y += 26
    # a round red stamp near the bottom of the seal
    d.ellipse((cx - 9, sy1 - 30, cx + 9, sy1 - 12), outline=(170, 34, 28, 255), width=3)
    d.line(((cx, sy1 - 27), (cx, sy1 - 15)), fill=(170, 34, 28, 255), width=2)
    # weathering on the paper
    px = np.asarray(im).astype(float)
    n = np.random.default_rng(2).normal(0, 6, px.shape[:2])
    px[sy0:sy1, sx0:sx1, :3] += n[sy0:sy1, sx0:sx1, None]
    im = Image.fromarray(np.clip(px, 0, 255).astype(np.uint8), "RGBA")
    im.save(out("textures", "entity", "edo_tensei", "coffin.png"))
    return im


# ------------------------------------------------------------------ the cracks over the reanimated body

S = 4  # cracks.png is the 64x64 skin layout drawn 4x finer

# the base layer's boxes in skin pixels: (u, v, width, height, depth) of each part's unwrapped box
PARTS = {
    "head": (0, 0, 8, 8, 8),
    "body": (16, 16, 8, 12, 4),
    "right_arm": (40, 16, 4, 12, 4),
    "left_arm": (32, 48, 4, 12, 4),
    "right_leg": (0, 16, 4, 12, 4),
    "left_leg": (16, 48, 4, 12, 4),
}


def crack(d, start, angle, length, width, rnd, depth=0):
    """A crack: a jagged line wandering from start, now and then splitting in two."""
    x, y = start
    pts = [(x, y)]
    step = 1.6
    n = int(length / step)
    for i in range(n):
        angle += rnd.uniform(-0.55, 0.55)
        x += math.cos(angle) * step
        y += math.sin(angle) * step
        pts.append((x, y))
        if depth < 2 and rnd.random() < 0.09:
            crack(d, (x, y), angle + rnd.choice((-1, 1)) * rnd.uniform(0.6, 1.2), length * rnd.uniform(0.25, 0.5),
                  max(1, width - 1), rnd, depth + 1)
    d.line(pts, fill=255, width=width, joint="curve")


def part_mask(u, v, w, h, dp, size):
    m = Image.new("L", (size, size), 0)
    d = ImageDraw.Draw(m)
    d.rectangle(((u + dp) * S, v * S, (u + dp + 2 * w) * S - 1, (v + dp) * S - 1), fill=255)
    d.rectangle((u * S, (v + dp) * S, (u + 2 * (dp + w)) * S - 1, (v + dp + h) * S - 1), fill=255)
    return np.asarray(m)


FACE_KEYS = ("top", "bottom", "right", "front", "left", "back")


def faces(u, v, w, h, d):
    """The six faces of a skin box, unwrapped: name -> (x, y, width, height) in skin pixels."""
    return {"top": (u + d, v, w, d), "bottom": (u + d + w, v, w, d), "right": (u, v + d, d, h),
            "front": (u + d, v + d, w, h), "left": (u + d + w, v + d, d, h), "back": (u + 2 * d + w, v + d, w, h)}


def cracks_texture():
    """Cracks over every face of every part (head, body, arms, legs, hands and feet), the face's own pattern
    running down from the eyes, and black whites of the eyes."""
    size = 64 * S
    rnd = random.Random(1946)
    total = np.zeros((size, size))
    allowed = np.zeros((size, size))
    for name, box in PARTS.items():
        for fname, (fx, fy, fw, fh) in faces(*box).items():
            if fw == 0 or fh == 0:
                continue
            own = np.zeros((size, size))
            own[fy * S:(fy + fh) * S, fx * S:(fx + fw) * S] = 1
            allowed = np.maximum(allowed, own)
            layer = Image.new("L", (size, size), 0)
            d = ImageDraw.Draw(layer)
            face_front = name == "head" and fname == "front"
            if face_front:
                # the face: cracks running down from under each eye to the jaw, the look this jutsu is known for
                for ex, side in ((9.5, -1), (14.5, 1)):
                    crack(d, (ex * S, 13.0 * S), math.pi / 2 + side * 0.15, 3.2 * S, 2, rnd)
                    crack(d, ((ex + side * 0.6) * S, 13.0 * S), math.pi / 2 + side * 0.7, 2.6 * S, 1, rnd)
                    crack(d, ((ex - side * 0.4) * S, 11.6 * S), -math.pi / 2 - side * 0.3, 1.8 * S, 1, rnd)
                crack(d, (11.0 * S, 8.6 * S), math.pi / 2 + 0.4, 2.2 * S, 1, rnd)      # the forehead
                crack(d, (13.4 * S, 8.4 * S), math.pi / 2 - 0.2, 1.8 * S, 1, rnd)
                crack(d, (8.1 * S, 15.4 * S), -0.15, 2.0 * S, 1, rnd)                 # along the jaw
                crack(d, (15.9 * S, 15.4 * S), math.pi + 0.15, 2.0 * S, 1, rnd)
                crack(d, (12.0 * S, 15.9 * S), -math.pi / 2 + 0.2, 1.5 * S, 1, rnd)   # the chin
            else:
                # everywhere else: a web of cracks, about one for every 5 square pixels, some running off the edges
                n = max(2, int(round(fw * fh / 5)))
                for _ in range(n):
                    sx = fx + rnd.uniform(-0.3, fw + 0.3)
                    sy = fy + rnd.uniform(-0.3, fh + 0.3)
                    crack(d, (sx * S, sy * S), rnd.uniform(0, math.pi * 2), rnd.uniform(2.0, 4.0) * S,
                          rnd.choice((1, 1, 1, 2)), rnd)
            total = np.maximum(total, np.asarray(layer).astype(float) * own)
    mask = Image.fromarray(total.astype(np.uint8))
    # dark lines with a faint grey ash rim either side
    rim = mask.filter(ImageFilter.MaxFilter(5)).filter(ImageFilter.GaussianBlur(1.2))
    line = total / 255
    rim = np.asarray(rim).astype(float) / 255 * (allowed > 0)
    img = np.zeros((size, size, 4))
    img[..., :3] = 150 * (1 - line[..., None]) + 18 * line[..., None]
    img[..., 3] = np.maximum(np.maximum(line * 235, rim * 70), (allowed > 0) * 38)   # and a faint ashen grey over all of it
    # the whites of the eyes turn black (the skin's usual eye pixels: x 9 and 14 on row 12 of the face)
    for ex in (9, 14):
        img[12 * S:13 * S, ex * S:(ex + 1) * S] = (10, 10, 12, 255)
    Image.fromarray(np.clip(img, 0, 255).astype(np.uint8), "RGBA").save(out("textures", "entity", "edo_tensei", "cracks.png"))


# ------------------------------------------------------------------ nameless souls (my own designs)

OUTER = {"head": (32, 0, 8, 8, 8), "body": (16, 32, 8, 12, 4), "right_arm": (40, 32, 4, 12, 4),
         "left_arm": (48, 48, 4, 12, 4), "right_leg": (0, 32, 4, 12, 4), "left_leg": (0, 48, 4, 12, 4)}


def soul_skin(path, design, seed):
    """A 64x64 skin: every face filled from the design's colours, with a little cloth noise and shading."""
    rnd = np.random.default_rng(seed)
    img = np.zeros((64, 64, 4))

    def paint(box, fn):
        for fname, (fx, fy, fw, fh) in faces(*box).items():
            for y in range(fh):
                for x in range(fw):
                    c = fn(fname, x, y, fw, fh)
                    if c is None:
                        continue
                    n = rnd.normal(0, 5)
                    img[fy + y, fx + x] = (*np.clip(np.array(c[:3]) + n, 0, 255), c[3] if len(c) > 3 else 255)

    for part in PARTS:
        paint(PARTS[part], lambda f, x, y, w, h, part=part: design(part, f, x, y, w, h, False))
        paint(OUTER[part], lambda f, x, y, w, h, part=part: design(part, f, x, y, w, h, True))
    Image.fromarray(np.clip(img, 0, 255).astype(np.uint8), "RGBA").save(path)


def wanderer(part, f, x, y, w, h, outer):
    """A wanderer in a dark hooded travelling cloak."""
    skin, hair, cloak, trim, wrap = (196, 156, 122), (52, 40, 34), (46, 48, 56), (92, 30, 30), (210, 205, 190)
    if part == "head":
        if outer:  # the hood
            if f == "front":
                return (*cloak, 255) if y < 2 or x in (0, 7) else None
            return (*cloak, 255) if f != "bottom" else None
        if f == "front":
            if y < 3:
                return hair
            if y == 4 and x in (1, 6):
                return (235, 235, 235)
            if y == 4 and x in (2, 5):
                return (70, 60, 50)
            if y >= 6:
                return wrap  # a cloth mask over the mouth
            return skin
        return hair if f in ("top", "back") or y < 3 else skin
    if outer:
        if part == "body":
            return (*cloak, 255) if not (f == "front" and 3 <= x <= 4) else None
        if part in ("right_arm", "left_arm"):
            return (*cloak, 255) if y < 9 else None
        return None
    if part == "body":
        if f == "front" and 3 <= x <= 4:
            return (60, 64, 72)
        return trim if y == 7 else (60, 64, 72)
    if part in ("right_arm", "left_arm"):
        return skin if y >= 10 else wrap if y >= 8 else cloak
    return (30, 30, 34) if y >= 10 else (64, 68, 76) if y < 7 else wrap


def guard(part, f, x, y, w, h, outer):
    """A village guard: dark blue clothes, a grey padded vest and a plain metal-plated headband."""
    skin, hair, cloth, vest, band, plate = (220, 176, 140), (150, 98, 54), (36, 44, 68), (110, 116, 108), (28, 30, 44), (176, 182, 190)
    if part == "head":
        if outer:
            if f in ("front", "right", "left", "back") and y == 2:
                return (*(plate if f == "front" and 2 <= x <= 5 else band), 255)
            return (*hair, 255) if f == "top" or (f == "back" and y < 6) else None
        if f == "front":
            if y < 2:
                return hair
            if y == 4 and x in (1, 6):
                return (240, 240, 240)
            if y == 4 and x in (2, 5):
                return (40, 80, 60)
            if y == 6 and 3 <= x <= 4:
                return (150, 100, 80)
            return skin
        return hair if f in ("top", "back") or y < 2 else skin
    if outer:
        if part == "body" and f != "bottom" and y < 10:
            return (*vest, 255) if not (f == "front" and x in (3, 4)) else (*(80, 84, 80), 255)
        return None
    if part == "body":
        return cloth
    if part in ("right_arm", "left_arm"):
        return skin if y >= 10 else cloth
    return (24, 24, 30) if y >= 9 else (225, 225, 225) if y == 8 else cloth


def ronin(part, f, x, y, w, h, outer):
    """A swordsman in a pale robe over grey trousers, black hair tied up."""
    skin, hair, robe, sash, pants = (206, 166, 132), (22, 20, 22), (214, 210, 198), (60, 40, 70), (88, 90, 96)
    if part == "head":
        if outer:
            if f == "top" and 3 <= x <= 4 and 3 <= y <= 4:
                return (*hair, 255)  # the topknot
            if f == "back" and y < 5:
                return (*hair, 255)
            return None
        if f == "front":
            if y < 2 or (y < 3 and x in (0, 7)):
                return hair
            if y == 4 and x in (1, 6):
                return (238, 238, 238)
            if y == 4 and x in (2, 5):
                return (50, 34, 30)
            if y == 6 and 2 <= x <= 5:
                return (160, 110, 90)
            return skin
        return hair if f in ("top", "back") or y < 2 else skin
    if outer:
        if part in ("right_arm", "left_arm") and y < 8 and f != "top":
            return (*robe, 255)
        return None
    if part == "body":
        if y == 8 or y == 9:
            return sash
        if f == "front" and (x == y // 2 + 1 or 7 - x == y // 2 + 1) and y < 8:
            return (150, 146, 136)  # the robe's crossed collar
        if f == "front" and y < 8 and (y // 2 + 1) < x < 7 - (y // 2 + 1):
            return skin
        return robe
    if part in ("right_arm", "left_arm"):
        return skin if y >= 8 else robe
    return (60, 46, 34) if y >= 11 else pants


SOULS = [wanderer, guard, ronin]


GLB = os.path.join(HERE, "source_art", "edo_coffin.glb")
HEIGHT = 2.3
LID_INNER_Z = 0.2  # where the inside of the shut lid sits (room for a body standing at z = 0)


def coffin_from_glb():
    """The GLB coffin, upright: glTF has it lying on its back (height along z, lid up along +y)."""
    import io
    import sys
    sys.path.insert(0, HERE)
    import gltf_reader
    parts, _ = gltf_reader.load_parts(GLB, None)
    j, blob = gltf_reader.read(GLB)
    bv = j["bufferViews"][j["images"][j["textures"][0]["source"]]["bufferView"]]
    o = bv.get("byteOffset", 0)
    tex = Image.open(io.BytesIO(blob[o:o + bv["byteLength"]])).convert("RGB")
    # (x, y, z) -> (x, -z, y): stood up (head end up), lid facing +z (a proper rotation, so faces keep their winding)
    allv = np.vstack([m.vertices for _, m, _ in parts])
    lo, hi = allv.min(0), allv.max(0)
    s = HEIGHT / (hi[2] - lo[2])
    lid_inner = min(m.vertices[:, 1].min() for name, m, _ in parts if name.startswith("Tapa"))
    origin = np.array([(lo[0] + hi[0]) / 2, lid_inner - LID_INNER_Z / s, hi[2]])

    def convert(m):
        v = (m.vertices - origin) * s
        P = np.column_stack([v[:, 0], -v[:, 2], v[:, 1]])
        n = m.vertex_normals
        N = np.column_stack([n[:, 0], -n[:, 2], n[:, 1]])
        UV = np.column_stack([m.visual.uv[:, 0], 1.0 - m.visual.uv[:, 1]])   # back to top-down v
        return P, N, UV

    body, lid = [], []
    lid_pts = [convert(m)[0] for name, m, _ in parts if name.startswith("Tapa")]
    lp = np.vstack(lid_pts)
    hinge = np.array([0.0, lp[:, 1].min(), lp[:, 2].max()])
    for name, m, _ in parts:
        P, N, UV = convert(m)
        is_lid = name.startswith("Tapa")
        if is_lid:
            P = P - hinge
        for a, b, c in m.faces:
            uv = UV[[a, b, c]]
            uv = uv - np.floor(uv.min(0))                    # keep each triangle's UVs near 0..1 (the texture repeats)
            tri = (tuple(map(tuple, P[[a, b, c]])), tuple(map(tuple, uv)), tuple(map(tuple, N[[a, b, c]])))
            (lid if is_lid else body).append(tri)
    tex.resize((512, 512), Image.LANCZOS).save(out("textures", "entity", "edo_tensei", "coffin.png"), optimize=True)
    return body, lid, hinge


if __name__ == "__main__":
    if os.path.exists(GLB):
        body, lid, hinge = coffin_from_glb()
        print("lid hinge (put in FxEdo.HINGE_Y / HINGE_Z): y=%.4f z=%.4f" % (hinge[1], hinge[2]))
    else:
        body, lid = coffin()
        coffin_texture()
    write_mesh(out("meshes", "edo_coffin.bin"), [(0, 1.0, body), (0, 1.0, lid)])
    cracks_texture()
    for i, design in enumerate(SOULS):
        soul_skin(out("textures", "entity", "edo_tensei", "souls", "soul_%d.png" % i), design, i)
    print("coffin:", len(body), "+", len(lid), "triangles")
