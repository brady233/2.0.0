package com.shinobiarts.ninja;

import com.shinobiarts.Config;
import com.shinobiarts.jutsu.JutsuUtil;
import com.shinobiarts.network.ModNetwork;
import com.shinobiarts.registry.ModDamage;
import net.minecraft.ChatFormatting;
import net.minecraft.core.particles.DustParticleOptions;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.effect.MobEffect;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.decoration.ArmorStand;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.Vec3;
import org.joml.Vector3f;

import javax.annotation.Nullable;

/**
 * Jinchuriki: a tailed beast sealed inside a player.
 * <ul>
 *   <li><b>Rage forms</b> (1 to 6 tails, at most the beast's own): the beast's chakra bursts out as a shroud with that
 *       many tails and takes over. The jinchuriki can't control their body (the client drives it: it hunts the
 *       nearest creature and tears into it) until the form burns out. Time spent in the highest form they've reached
 *       earns EXP; enough of it (2 tails: 400, 3 tails: 600, then 200 more each) unlocks the next.</li>
 *   <li><b>Chakra cloak</b>: past the last rage form the beast is tamed. Its cloak (its own colour, markings and tails)
 *       is under the jinchuriki's control: strength, speed, healing and the Tailed Beast Bomb (right-click).</li>
 * </ul>
 * Given and taken by /jinchuriki.
 */
public final class Jinchuriki {
    public static final int NONE = 0, CLOAK = 10;

    private Jinchuriki() {}

    /** A player's beast and how far they've come with it (saved with their ninja data). */
    public static final class State {
        public int beast;            // 0 = none, else the beast's tail count
        public int form;             // 0 none, 1-6 a rage form's tails, CLOAK
        public int unlocked = 1;     // the highest rage form reached
        public boolean cloak;
        public float exp;            // towards the next form
        public long until;           // a rage form burns out then
        public long cooldownUntil;

        @Nullable
        public TailedBeast beast() {
            return TailedBeast.byTails(beast);
        }

        public boolean rage() {
            return form >= 1 && form <= 9;
        }

        /** EXP needed for what this form is working towards, or 0 if it isn't working towards anything. */
        public float needed() {
            TailedBeast b = beast();
            if (b == null) return 0;
            int step = Config.i(Config.JIN_EXP_STEP);
            if (rage() && form == unlocked && unlocked < b.maxRage()) return step * (unlocked + 1);
            if (rage() && form == b.maxRage() && !cloak) return step * (b.maxRage() + 1);
            return 0;
        }

        public CompoundTag save() {
            CompoundTag t = new CompoundTag();
            t.putInt("Beast", beast);
            t.putInt("Form", form);
            t.putInt("Unlocked", unlocked);
            t.putBoolean("Cloak", cloak);
            t.putFloat("Exp", exp);
            t.putLong("Until", until);
            t.putLong("Cooldown", cooldownUntil);
            return t;
        }

        public void load(CompoundTag t) {
            beast = t.getInt("Beast");
            form = t.getInt("Form");
            if (form > CLOAK) form = NONE;
            unlocked = Math.max(1, t.getInt("Unlocked"));
            cloak = t.getBoolean("Cloak");
            exp = t.getFloat("Exp");
            until = t.getLong("Until");
            cooldownUntil = t.getLong("Cooldown");
        }
    }

    private static void say(ServerPlayer p, String key, ChatFormatting color, Object... args) {
        p.displayClientMessage(Component.translatable("message.shinobiarts." + key, args).withStyle(color), true);
    }

    private static DustParticleOptions dust(int rgb, float size) {
        return new DustParticleOptions(new Vector3f(((rgb >> 16) & 255) / 255f, ((rgb >> 8) & 255) / 255f, (rgb & 255) / 255f), size);
    }

    // ================================================================ giving and taking

    /** Seals {@code beast} into the player (taking it from anyone else who holds it, if only one may). */
    public static void give(ServerPlayer p, TailedBeast beast) {
        NinjaData d = NinjaData.get(p);
        if (d == null) return;
        if (Config.b(Config.JIN_ONE_PER_BEAST)) {
            for (ServerPlayer other : p.server.getPlayerList().getPlayers()) {
                NinjaData od = NinjaData.get(other);
                if (other != p && od != null && od.jin.beast == beast.tails) remove(other);
            }
        }
        end(p, d, false);
        State s = d.jin;
        s.beast = beast.tails;
        s.form = NONE;
        s.unlocked = 1;
        s.cloak = false;
        s.exp = 0;
        s.cooldownUntil = 0;
        p.sendSystemMessage(Component.translatable("message.shinobiarts.jin_given", beast.displayName()).withStyle(ChatFormatting.GOLD));
        p.serverLevel().playSound(null, p.getX(), p.getY(), p.getZ(), SoundEvents.WITHER_SPAWN, SoundSource.PLAYERS, 0.6f, 0.8f);
        ModNetwork.sync(p);
        SharinganManager.broadcastEyes(p);
    }

    public static void remove(ServerPlayer p) {
        NinjaData d = NinjaData.get(p);
        if (d == null || d.jin.beast == 0) return;
        end(p, d, false);
        d.jin.beast = 0;
        d.jin.form = NONE;
        p.sendSystemMessage(Component.translatable("message.shinobiarts.jin_removed").withStyle(ChatFormatting.GRAY));
        ModNetwork.sync(p);
        SharinganManager.broadcastEyes(p);
    }

    // ================================================================ the key

    /** The Tailed Beast key: into the highest rage form, or (once tamed) the cloak; again to let the cloak go. */
    public static void key(ServerPlayer p, NinjaData d) {
        State s = d.jin;
        TailedBeast b = s.beast();
        if (b == null) {
            say(p, "jin_none", ChatFormatting.GRAY);
            return;
        }
        long now = p.level().getGameTime();
        if (s.rage()) {
            say(p, "jin_no_control", ChatFormatting.DARK_RED);
            return;
        }
        if (s.form == CLOAK) {
            end(p, d, true);
            return;
        }
        if (now < s.cooldownUntil) {
            say(p, "jin_cooldown", ChatFormatting.GRAY, String.format("%.0f", (s.cooldownUntil - now) / 20.0));
            return;
        }
        if (d.getSusanooStage() > 0) return;
        if (s.cloak) enter(p, d, CLOAK, now);
        else enter(p, d, Math.min(s.unlocked, b.maxRage()), now);
    }

    private static void enter(ServerPlayer p, NinjaData d, int form, long now) {
        State s = d.jin;
        TailedBeast b = s.beast();
        if (b == null) return;
        s.form = form;
        ServerLevel level = p.serverLevel();
        Vec3 at = p.position().add(0, 1, 0);
        level.sendParticles(dust(form >= 4 && form <= 9 ? b.dark : b.color, 3f), at.x, at.y, at.z, 120, 0.8, 1.2, 0.8, 0.0);
        if (form >= 1 && form <= 9) {
            s.until = now + Math.round((Config.d(Config.JIN_RAGE_SECONDS) + Config.d(Config.JIN_RAGE_PER_TAIL) * (form - 1)) * 20);
            say(p, "jin_rage", ChatFormatting.DARK_RED, b.displayName(), form);
            level.playSound(null, p.getX(), p.getY(), p.getZ(), SoundEvents.RAVAGER_ROAR, SoundSource.PLAYERS, 1.5f, 1.3f - form * 0.08f);
        } else {
            say(p, "jin_cloak", ChatFormatting.GOLD, b.displayName());
            level.playSound(null, p.getX(), p.getY(), p.getZ(), SoundEvents.BEACON_ACTIVATE, SoundSource.PLAYERS, 1.2f, 0.8f);
            level.playSound(null, p.getX(), p.getY(), p.getZ(), SoundEvents.ENDER_DRAGON_GROWL, SoundSource.PLAYERS, 0.8f, 1.2f);
        }
        ModNetwork.sync(p);
        SharinganManager.broadcastEyes(p);
    }

    /** The form ends (a rage form burning out, or the jinchuriki letting it go). */
    public static void end(ServerPlayer p, NinjaData d, boolean cooldown) {
        State s = d.jin;
        if (s.form == NONE) return;
        boolean wasRage = s.rage();
        s.form = NONE;
        long now = p.level().getGameTime();
        if (cooldown) s.cooldownUntil = now + Math.round(Config.d(Config.JIN_COOLDOWN) * 20);
        if (wasRage) {                                     // spent: the beast's chakra drains away and leaves them weak
            p.addEffect(new MobEffectInstance(MobEffects.MOVEMENT_SLOWDOWN, 300, 1));
            p.addEffect(new MobEffectInstance(MobEffects.WEAKNESS, 300, 0));
            say(p, "jin_rage_end", ChatFormatting.GRAY);
        }
        ModNetwork.sync(p);
        SharinganManager.broadcastEyes(p);
    }

    // ================================================================ every tick

    public static void tick(ServerPlayer p, NinjaData d) {
        State s = d.jin;
        if (s.beast == 0) {
            if (s.form != NONE) s.form = NONE;
            return;
        }
        if (s.form == NONE) return;
        TailedBeast b = s.beast();
        long now = p.level().getGameTime();
        if (!p.isAlive() || p.isSpectator() || b == null) {
            end(p, d, true);
            return;
        }
        // EXP for the next form
        float need = s.needed();
        if (need > 0) {
            s.exp += Config.f(Config.JIN_EXP_PER_SECOND) / 20f;
            if (s.exp >= need) unlockNext(p, d, b);
            else if (p.tickCount % 40 == 0) ModNetwork.sync(p);
        }
        if (s.rage()) {
            rageTick(p, d, b, now);
            if (now >= s.until) end(p, d, true);
        } else if (s.form == CLOAK) {
            if (p.tickCount % 20 == 0) {
                buff(p, MobEffects.DAMAGE_BOOST, 2);
                buff(p, MobEffects.MOVEMENT_SPEED, 2);
                buff(p, MobEffects.DAMAGE_RESISTANCE, 1);
                buff(p, MobEffects.REGENERATION, 1);
                buff(p, MobEffects.JUMP, 2);
                buff(p, MobEffects.DIG_SPEED, 1);
                if (!drain(p, d, Config.f(Config.JIN_CLOAK_DRAIN))) end(p, d, true);
            }
        }
    }

    private static boolean drain(ServerPlayer p, NinjaData d, float share) {
        if (p.isCreative()) return true;
        float cost = share * d.maxChakra();
        if (d.getChakra() < cost) {
            say(p, "jin_no_chakra", ChatFormatting.RED);
            return false;
        }
        d.consumeChakra(cost);
        return true;
    }

    private static void buff(ServerPlayer p, MobEffect effect, int amp) {
        p.addEffect(new MobEffectInstance(effect, 40, amp, false, false, true));
    }

    private static void unlockNext(ServerPlayer p, NinjaData d, TailedBeast b) {
        State s = d.jin;
        s.exp = 0;
        ServerLevel level = p.serverLevel();
        if (s.rage() && s.unlocked < b.maxRage()) {
            s.unlocked++;
            p.sendSystemMessage(Component.translatable("message.shinobiarts.jin_unlocked", b.displayName(), s.unlocked).withStyle(ChatFormatting.GOLD));
        } else if (s.rage() && !s.cloak) {
            s.cloak = true;
            p.sendSystemMessage(Component.translatable("message.shinobiarts.jin_cloak_unlocked", b.displayName()).withStyle(ChatFormatting.GOLD));
        }
        level.playSound(null, p.getX(), p.getY(), p.getZ(), SoundEvents.PLAYER_LEVELUP, SoundSource.PLAYERS, 1.0f, 0.7f);
        ModNetwork.sync(p);
    }

    /**
     * The beast in charge: stronger, faster and tougher with every tail, healing; it tears into whatever is nearest
     * (the client moves and turns the body), and from four tails its roar blasts everything back.
     */
    private static void rageTick(ServerPlayer p, NinjaData d, TailedBeast b, long now) {
        int k = d.jin.form;
        if (p.tickCount % 20 == 0) {
            buff(p, MobEffects.DAMAGE_BOOST, Math.min(3, (k + 1) / 2));
            buff(p, MobEffects.MOVEMENT_SPEED, Math.min(2, k / 2));
            buff(p, MobEffects.DAMAGE_RESISTANCE, Math.min(2, (k - 1) / 2));
            buff(p, MobEffects.REGENERATION, k >= 4 ? 1 : 0);
            buff(p, MobEffects.JUMP, 1);
            buff(p, MobEffects.FIRE_RESISTANCE, 0);
        }
        ServerLevel level = p.serverLevel();
        if (p.tickCount % 12 == 0) {
            LivingEntity target = nearest(p, 3.6);
            if (target != null) {
                p.swing(p.tickCount % 24 == 0 ? InteractionHand.MAIN_HAND : InteractionHand.OFF_HAND, true);
                target.invulnerableTime = 0;
                target.hurt(ModDamage.jutsu(level, p, p), Config.f(Config.JIN_RAGE_DAMAGE) + 2f * k);
                Vec3 away = target.position().subtract(p.position());
                away = new Vec3(away.x, 0, away.z);
                JutsuUtil.push(target, (away.lengthSqr() < 1e-4 ? new Vec3(0, 0, 1) : away.normalize()).scale(0.6 + 0.1 * k).add(0, 0.3, 0));
                level.sendParticles(dust(k >= 4 ? b.dark : b.color, 2.2f), target.getX(), target.getY() + 1, target.getZ(), 16, 0.4, 0.5, 0.4, 0.0);
                level.playSound(null, target.getX(), target.getY(), target.getZ(), SoundEvents.PLAYER_ATTACK_STRONG, SoundSource.PLAYERS, 1.0f, 0.7f);
            }
        }
        if (k >= 4 && p.tickCount % 100 == 0) {             // the roar
            for (LivingEntity e : JutsuUtil.inRadius(level, p, p.position(), 6 + k)) {
                if (e == p) continue;
                e.hurt(ModDamage.jutsu(level, p, p), 2f + k);
                Vec3 away = e.position().subtract(p.position()).normalize();
                JutsuUtil.push(e, away.scale(1.2).add(0, 0.5, 0));
            }
            level.sendParticles(dust(b.dark, 3f), p.getX(), p.getY() + 1, p.getZ(), 80, 3, 1, 3, 0.0);
            level.playSound(null, p.getX(), p.getY(), p.getZ(), SoundEvents.RAVAGER_ROAR, SoundSource.PLAYERS, 2.0f, 0.6f);
        }
        if (p.tickCount % 3 == 0) {                          // the beast's chakra boiling off them
            int c = k >= 4 ? b.dark : b.color;
            level.sendParticles(dust(c, 1.8f), p.getX(), p.getY() + 1, p.getZ(), 4, 0.4, 0.8, 0.4, 0.0);
        }
    }

    /** The nearest creature a raging jinchuriki would go for (anyone at all: it can't tell friend from foe). */
    @Nullable
    public static LivingEntity nearest(net.minecraft.world.entity.player.Player p, double range) {
        LivingEntity best = null;
        double bestD = range * range;
        for (LivingEntity e : p.level().getEntitiesOfClass(LivingEntity.class, new AABB(p.blockPosition()).inflate(range),
                e -> e != p && e.isAlive() && !(e instanceof ArmorStand) && !e.isSpectator() && !e.isInvisible()
                        && !(e instanceof net.minecraft.world.entity.player.Player pl && pl.isCreative()))) {
            double dd = e.distanceToSqr(p);
            if (dd < bestD) {
                bestD = dd;
                best = e;
            }
        }
        return best;
    }
}
