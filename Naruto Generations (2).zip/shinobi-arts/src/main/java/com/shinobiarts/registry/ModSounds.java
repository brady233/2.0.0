package com.shinobiarts.registry;

import com.shinobiarts.ShinobiArts;
import com.shinobiarts.jutsu.Jutsu;
import com.shinobiarts.jutsu.Jutsus;
import com.shinobiarts.ninja.EyeTechniques;
import net.minecraft.core.registries.Registries;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.sounds.SoundEvent;
import net.minecraft.sounds.SoundSource;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.registries.RegistryObject;

import java.util.HashMap;
import java.util.Map;

/**
 * Voice lines: every jutsu (shinobiarts:jutsu.<id>) and every eye technique (shinobiarts:eye.<id>) has a sound of its
 * own, played from the caster when it goes off, on top of the jutsu's effect sounds. Each one plays
 * assets/shinobiarts/sounds/voice/<id>.ogg (mono OGG Vorbis), so adding a voice line only takes dropping the file in
 * that folder (in the mod, or a resource pack); until a file is there the sound is silent. Some jutsu share a
 * file (the Wood Release jutsu, the clone jutsu, Kamui). The list is in sounds.json.
 */
public final class ModSounds {
    public static final DeferredRegister<SoundEvent> SOUNDS = DeferredRegister.create(Registries.SOUND_EVENT, ShinobiArts.MODID);

    /** A shadow clone vanishing in a puff of smoke. */
    public static final RegistryObject<SoundEvent> CLONE_POOF = register("shadow_clone_poof");
    /** The Sharingan coming on (any stage: tomoe, Mangekyou, Eternal). */
    public static final RegistryObject<SoundEvent> SHARINGAN_ON = register("sharingan_on");
    /** The Mangekyou switching off. */
    public static final RegistryObject<SoundEvent> MANGEKYOU_OFF = register("mangekyou_off");
    /** The Rasenshuriken's shrill ringing whine and roaring wind (looped while it's held or flying). */
    public static final RegistryObject<SoundEvent> RASENSHURIKEN_LOOP = register("rasenshuriken_loop");
    /** The Rasenshuriken detonating into its sphere of wind blades. */
    public static final RegistryObject<SoundEvent> RASENSHURIKEN_BURST = register("rasenshuriken_burst");

    private static final Map<String, RegistryObject<SoundEvent>> JUTSU = new HashMap<>();
    private static final Map<String, RegistryObject<SoundEvent>> EYES = new HashMap<>();

    static {
        for (Jutsu j : Jutsus.all()) JUTSU.put(j.id(), register("jutsu." + j.id()));
        for (EyeTechniques.Technique t : EyeTechniques.Technique.values()) EYES.put(t.id(), register("eye." + t.id()));
    }

    private ModSounds() {}

    private static RegistryObject<SoundEvent> register(String name) {
        return SOUNDS.register(name, () -> SoundEvent.createVariableRangeEvent(ShinobiArts.id(name)));
    }

    /** Plays a jutsu's voice line from the caster. */
    public static void jutsu(ServerPlayer p, String jutsuId) {
        play(p, JUTSU.get(jutsuId));
    }

    /** Plays an eye technique's voice line from the caster. */
    public static void eye(ServerPlayer p, String techniqueId) {
        play(p, EYES.get(techniqueId));
    }

    /** An eye technique's sound event (the Kamui warp for Obito's shuriken...), or a stand-in if it's missing. */
    public static SoundEvent eyeSound(String techniqueId) {
        RegistryObject<SoundEvent> s = EYES.get(techniqueId);
        return s != null && s.isPresent() ? s.get() : net.minecraft.sounds.SoundEvents.ENDERMAN_TELEPORT;
    }

    /** Plays one of the sounds above from the player. */
    public static void at(ServerPlayer p, RegistryObject<SoundEvent> sound) {
        play(p, sound);
    }

    private static void play(ServerPlayer p, RegistryObject<SoundEvent> sound) {
        if (sound == null || !sound.isPresent()) return;
        p.level().playSound(null, p.getX(), p.getEyeY(), p.getZ(), sound.get(), SoundSource.PLAYERS, 1.0f, 1.0f);
    }
}
