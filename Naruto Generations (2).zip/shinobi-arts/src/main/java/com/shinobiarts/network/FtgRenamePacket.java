package com.shinobiarts.network;

import com.shinobiarts.ninja.FlyingThunderGod;
import net.minecraft.network.FriendlyByteBuf;
import net.minecraft.server.level.ServerPlayer;
import net.minecraftforge.network.NetworkEvent;

import java.util.function.Supplier;

/** Client -> server: give Flying Thunder God mark {@code id} the name {@code label} (empty: back to its own name). */
public class FtgRenamePacket {
    private final int id;
    private final String label;

    public FtgRenamePacket(int id, String label) {
        this.id = id;
        this.label = label;
    }

    public FtgRenamePacket(FriendlyByteBuf buf) {
        this.id = buf.readVarInt();
        this.label = buf.readUtf(FlyingThunderGod.MAX_LABEL);
    }

    public void encode(FriendlyByteBuf buf) {
        buf.writeVarInt(id);
        buf.writeUtf(label, FlyingThunderGod.MAX_LABEL);
    }

    public void handle(Supplier<NetworkEvent.Context> ctx) {
        ServerPlayer player = ctx.get().getSender();
        if (player != null) FlyingThunderGod.rename(player, id, label);
    }
}
