package com.shinobiarts.network;

import net.minecraft.nbt.CompoundTag;
import net.minecraft.network.FriendlyByteBuf;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.fml.DistExecutor;
import net.minecraftforge.network.NetworkEvent;

import java.util.function.Supplier;

/** Server -> client: open or refresh the village quest board / Kage menu. */
public class BoardPacket {
    private final CompoundTag tag;

    public BoardPacket(CompoundTag tag) {
        this.tag = tag;
    }

    public BoardPacket(FriendlyByteBuf buf) {
        CompoundTag read = buf.readNbt();
        this.tag = read == null ? new CompoundTag() : read;
    }

    public void encode(FriendlyByteBuf buf) {
        buf.writeNbt(tag);
    }

    public void handle(Supplier<NetworkEvent.Context> ctx) {
        DistExecutor.unsafeRunWhenOn(Dist.CLIENT, () -> () -> com.shinobiarts.client.ClientHooks.openBoard(tag));
    }
}
