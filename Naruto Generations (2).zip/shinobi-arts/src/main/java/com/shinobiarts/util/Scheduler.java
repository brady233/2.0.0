package com.shinobiarts.util;

import com.shinobiarts.ShinobiArts;
import net.minecraftforge.event.TickEvent;
import net.minecraftforge.event.server.ServerStoppedEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

/**
 * Runs server-side code a number of ticks from now (waves of Blaze Release spikes, the strikes of 64 Palms, the end of
 * a Tsukuyomi...). Tasks live only in memory: anything pending when the server stops is dropped, so a task must never
 * be the only thing that undoes a lasting change.
 */
@Mod.EventBusSubscriber(modid = ShinobiArts.MODID, bus = Mod.EventBusSubscriber.Bus.FORGE)
public final class Scheduler {
    private static final List<Task> TASKS = new ArrayList<>();
    private static final List<Task> ADDED = new ArrayList<>();
    private static long tick;

    private record Task(long at, Runnable action) {}

    private Scheduler() {}

    /** Runs {@code action} on the server thread after {@code delayTicks} ticks (0 = at the end of this tick). */
    public static void later(int delayTicks, Runnable action) {
        // a task scheduled during a cast keeps the cast's damage, charge and size
        ADDED.add(new Task(tick + Math.max(0, delayTicks), com.shinobiarts.jutsu.JutsuUtil.bind(action)));
    }

    /** Runs {@code action(i)} for i = 0 .. times-1, every {@code interval} ticks, starting after {@code delay}. */
    public static void repeat(int delay, int interval, int times, java.util.function.IntConsumer action) {
        for (int i = 0; i < times; i++) {
            int index = i;
            later(delay + i * interval, () -> action.accept(index));
        }
    }

    @SubscribeEvent
    public static void onServerTick(TickEvent.ServerTickEvent event) {
        if (event.phase != TickEvent.Phase.END) return;
        TASKS.addAll(ADDED);
        ADDED.clear();
        Iterator<Task> it = TASKS.iterator();
        List<Task> due = new ArrayList<>();
        while (it.hasNext()) {
            Task t = it.next();
            if (t.at() <= tick) {
                due.add(t);
                it.remove();
            }
        }
        for (Task t : due) {
            try {
                t.action().run();
            } catch (RuntimeException e) {
                ShinobiArts.LOGGER.error("Scheduled task failed", e);
            }
        }
        tick++;
    }

    @SubscribeEvent
    public static void onServerStopped(ServerStoppedEvent event) {
        TASKS.clear();
        ADDED.clear();
    }
}
