package com.shinobiarts.client;

import com.shinobiarts.ShinobiArts;
import com.shinobiarts.entity.JutsuProjectile;
import com.shinobiarts.entity.ShadowClone;
import com.shinobiarts.ninja.SharinganManager;
import com.shinobiarts.registry.ModSounds;
import net.minecraft.client.Minecraft;
import net.minecraft.client.resources.sounds.AbstractTickableSoundInstance;
import net.minecraft.client.resources.sounds.SoundInstance;
import net.minecraft.sounds.SoundSource;
import net.minecraft.util.RandomSource;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.player.Player;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.event.TickEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;

import java.util.HashMap;
import java.util.Map;
import java.util.function.Predicate;

/**
 * The Rasenshuriken's shrill ringing whine: it loops from whoever holds one (a player or a shadow clone) and from a
 * thrown one in flight, following it, and stops when it's gone.
 */
@Mod.EventBusSubscriber(modid = ShinobiArts.MODID, bus = Mod.EventBusSubscriber.Bus.FORGE, value = Dist.CLIENT)
public final class RasenshurikenSound extends AbstractTickableSoundInstance {
    private static final Map<Integer, RasenshurikenSound> PLAYING = new HashMap<>();

    private final Entity entity;
    private final Predicate<Entity> still;
    private int age;

    private RasenshurikenSound(Entity entity, Predicate<Entity> still) {
        super(ModSounds.RASENSHURIKEN_LOOP.get(), SoundSource.PLAYERS, RandomSource.create());
        this.entity = entity;
        this.still = still;
        this.looping = true;
        this.delay = 0;
        this.volume = 0.01f;
        this.pitch = 1f;
        this.attenuation = SoundInstance.Attenuation.LINEAR;
        this.relative = false;
        follow();
    }

    private void follow() {
        x = entity.getX();
        y = entity.getY() + entity.getBbHeight() * 0.6;
        z = entity.getZ();
    }

    @Override
    public void tick() {
        if (entity.isRemoved() || !still.test(entity)) {
            stop();
            PLAYING.remove(entity.getId());
            return;
        }
        follow();
        age++;
        volume = Math.min(1.6f, 0.15f + age * 0.08f);                // it rises as the blades spin up
        pitch = 0.94f + 0.06f * (float) Math.sin(age * 0.21);
    }

    @Override
    public boolean canStartSilent() {
        return true;
    }

    private static boolean holding(Entity e) {
        if (e instanceof Player p) {
            int look = ClientEyes.look(p);
            return (look & SharinganManager.LOOK_RASENSHURIKEN) != 0 && (look & SharinganManager.LOOK_RASENGAN) != 0;
        }
        if (e instanceof ShadowClone c) return c.getHandJutsu() == ShadowClone.HandJutsu.RASENSHURIKEN;
        return e instanceof JutsuProjectile jp && jp.getKind() == JutsuProjectile.Kind.RASENSHURIKEN;
    }

    @SubscribeEvent
    public static void onClientTick(TickEvent.ClientTickEvent event) {
        if (event.phase != TickEvent.Phase.END) return;
        Minecraft mc = Minecraft.getInstance();
        if (mc.level == null || mc.player == null) {
            PLAYING.clear();
            return;
        }
        if (mc.level.getGameTime() % 4 != 0) return;
        for (Entity e : mc.level.entitiesForRendering()) {
            if (PLAYING.containsKey(e.getId()) || e.distanceToSqr(mc.player) > 64 * 64 || !holding(e)) continue;
            RasenshurikenSound s = new RasenshurikenSound(e, RasenshurikenSound::holding);
            PLAYING.put(e.getId(), s);
            mc.getSoundManager().play(s);
        }
    }
}
