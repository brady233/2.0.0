package com.shinobiarts.client.fx;

import com.mojang.blaze3d.vertex.VertexConsumer;
import com.shinobiarts.client.fx.FxDraw.Paint;
import net.minecraft.util.Mth;
import net.minecraft.util.RandomSource;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.phys.Vec3;

import java.util.ArrayList;
import java.util.List;

/**
 * Wood Release, the way the First Hokage's wood moves: thick bark-covered beams that grow, bend and wrap. Wood Binding
 * sends a root racing over the ground to the target and coils beams round it; Deep Forest Emergence raises a forest of
 * twisting trunks with branches and leaves that sinks back into the ground at the end.
 */
final class FxWood {
    private FxWood() {}

    static Paint bark(float alpha) {
        return FxDraw.block("minecraft:block/oak_log", 0xFFFFFF, alpha);
    }

    static Paint leaves() {
        return FxDraw.block("minecraft:block/oak_leaves", 0x5AA62C, 1f);
    }

    /** Part of a path: the first {@code grown} (0-1) of it. */
    static List<Vec3> grow(List<Vec3> path, float grown) {
        if (grown >= 1f) return path;
        List<Vec3> out = new ArrayList<>();
        float upto = grown * (path.size() - 1);
        int whole = (int) upto;
        for (int i = 0; i <= whole && i < path.size(); i++) out.add(path.get(i));
        if (whole + 1 < path.size()) out.add(path.get(whole).lerp(path.get(whole + 1), upto - whole));
        return out;
    }

    static float[] taper(int n, float r0, float r1) {
        float[] r = new float[n];
        for (int i = 0; i < n; i++) r[i] = n == 1 ? r0 : Mth.lerp(i / (float) (n - 1), r0, r1);
        return r;
    }

    /** Wood Binding: a root races over the ground from the caster, and four beams coil up round the target. */
    static void bind(FxClient.Ctx c) {
        Entity target = c.fx().entityA();
        if (target == null) return;
        float age = c.age();
        int ticks = c.fx().ticks;
        float retract = 1f - Mth.clamp((age - (ticks - 10)) / 10f, 0f, 1f);
        Vec3 feet = target.getPosition(c.partial());
        int light = FxDraw.lightAt(feet.add(0, 1, 0));
        VertexConsumer vc = FxDraw.blocks(c.buffers());
        Paint bark = bark(1f);
        // the root along the ground
        Vec3 from = c.fx().a;
        List<Vec3> root = new ArrayList<>();
        int seg = 14;
        Vec3 dir = feet.subtract(from).multiply(1, 0, 1);
        Vec3 side = dir.lengthSqr() > 1e-6 ? new Vec3(-dir.z, 0, dir.x).normalize() : new Vec3(1, 0, 0);
        for (int i = 0; i <= seg; i++) {
            float t = i / (float) seg;
            Vec3 p = from.lerp(feet, t).add(side.scale(Mth.sin(t * 9f + c.fx().seed) * 0.35f * Mth.sin(t * Mth.PI)));
            root.add(new Vec3(p.x, Mth.lerp(t, (float) from.y, (float) feet.y) + 0.12, p.z));
        }
        List<Vec3> rootNow = grow(root, Mth.clamp(age / 6f, 0f, 1f) * retract);
        if (rootNow.size() >= 2) FxDraw.tube(vc, c.ps(), rootNow, taper(rootNow.size(), 0.22f, 0.16f), 7, bark, 1.2f, light, true);
        // four beams climbing round the target
        float h = target.getBbHeight();
        float rad = target.getBbWidth() * 0.6f + 0.35f;
        for (int k = 0; k < 4; k++) {
            List<Vec3> beam = new ArrayList<>();
            float a0 = k * (Mth.PI / 2f) + c.fx().seed * 0.1f;
            for (int i = 0; i <= 16; i++) {
                float t = i / 16f;
                float ang = a0 + t * 4.2f;
                float r = Mth.lerp(t, rad + 0.6f, rad * 0.75f);
                beam.add(feet.add(Mth.cos(ang) * r, t * (h + 0.4f), Mth.sin(ang) * r));
            }
            float grown = Mth.clamp((age - 4 - k) / 8f, 0f, 1f) * retract;
            List<Vec3> now = grow(beam, grown);
            if (now.size() >= 2) FxDraw.tube(vc, c.ps(), now, taper(now.size(), 0.24f, 0.12f), 7, bark, 1.2f, light, true);
        }
    }

    /**
     * Deep Forest Emergence: twisting trunks burst up out of the ground over the area (each a beam of bark, bending as
     * it climbs, with branches and clumps of leaves), stand while the jutsu lasts, and sink back down at the end.
     */
    static void forest(FxClient.Ctx c) {
        Vec3 centre = c.fx().a;
        float age = c.age();
        int ticks = c.fx().ticks;
        float sink = Mth.clamp((age - (ticks - 20)) / 20f, 0f, 1f);
        RandomSource r = FxDraw.rng(c.fx().seed, 6);
        VertexConsumer vc = FxDraw.blocks(c.buffers());
        Paint bark = bark(1f);
        int light = FxDraw.lightAt(centre.add(0, 2, 0));
        for (int k = 0; k < 14; k++) {
            double x = centre.x + (r.nextDouble() - 0.5) * 9, z = centre.z + (r.nextDouble() - 0.5) * 9;
            double base = FxDraw.groundY(new Vec3(x, centre.y, z)) - 0.4;
            float height = 5 + r.nextFloat() * 5f;
            float lean = r.nextFloat() * Mth.TWO_PI, bend = 0.6f + r.nextFloat() * 1.2f, twist = r.nextFloat() * 6f;
            float delay = k * 0.9f;
            float grown = Mth.clamp((age - delay) / 10f, 0f, 1f);
            if (grown <= 0) continue;
            double drop = sink * (height + 1);
            List<Vec3> trunk = new ArrayList<>();
            for (int i = 0; i <= 12; i++) {
                float t = i / 12f;
                float wob = Mth.sin(t * 4f + twist) * 0.45f * t;
                trunk.add(new Vec3(x + Mth.cos(lean) * bend * t * t + Mth.cos(lean + 1.6f) * wob, base + t * height - drop,
                        z + Mth.sin(lean) * bend * t * t + Mth.sin(lean + 1.6f) * wob));
            }
            List<Vec3> now = grow(trunk, grown);
            FxDraw.tube(vc, c.ps(), now, taper(now.size(), 0.75f, 0.28f * (now.size() == trunk.size() ? 1f : 1.3f)), 8, bark, 0.6f, light, true);
            if (grown < 1f) continue;
            // branches from the upper half, each ending in a clump of leaves
            int branches = 2 + r.nextInt(3);
            for (int b = 0; b < branches; b++) {
                int at = 6 + r.nextInt(6);
                Vec3 start = trunk.get(at);
                float ba = r.nextFloat() * Mth.TWO_PI, bl = 1.5f + r.nextFloat() * 2f;
                List<Vec3> branch = new ArrayList<>();
                for (int i = 0; i <= 5; i++) {
                    float t = i / 5f;
                    branch.add(start.add(Mth.cos(ba) * bl * t, t * bl * 0.7f + Mth.sin(t * 3f) * 0.2f, Mth.sin(ba) * bl * t));
                }
                FxDraw.tube(vc, c.ps(), branch, taper(branch.size(), 0.22f, 0.08f), 6, bark, 0.8f, light, true);
                leafClump(vc, c, branch.get(branch.size() - 1), 0.9f + r.nextFloat() * 0.6f, r, light);
            }
            leafClump(vc, c, trunk.get(trunk.size() - 1), 1.3f + r.nextFloat() * 0.8f, r, light);
        }
    }

    private static void leafClump(VertexConsumer vc, FxClient.Ctx c, Vec3 at, float size, RandomSource r, int light) {
        Paint leaf = leaves();
        for (int i = 0; i < 4; i++) {
            Vec3 p = at.add(r.nextGaussian() * size * 0.4, r.nextGaussian() * size * 0.3, r.nextGaussian() * size * 0.4);
            float s = size * (0.45f + r.nextFloat() * 0.3f);
            FxDraw.box(vc, c.ps(), p, new Vec3(s, 0, 0), new Vec3(0, s * 0.8f, 0), new Vec3(0, 0, s), leaf, light);
        }
    }
}
