package com.shinobiarts.client;

import com.shinobiarts.ShinobiArts;
import com.shinobiarts.network.ActionPacket;
import com.shinobiarts.network.ModNetwork;
import com.shinobiarts.ninja.Jinchuriki;
import com.shinobiarts.ninja.NinjaData;
import net.minecraft.client.Minecraft;
import net.minecraft.client.player.Input;
import net.minecraft.client.player.LocalPlayer;
import net.minecraft.util.Mth;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.phys.Vec3;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.client.event.InputEvent;
import net.minecraftforge.client.event.MovementInputUpdateEvent;
import net.minecraftforge.event.TickEvent;
import net.minecraftforge.eventbus.api.EventPriority;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;

/**
 * The jinchuriki's side on the client: the Tailed Beast key, the beast taking over the body in a rage form (it turns
 * toward the nearest creature, runs it down and leaps after it; your keys and mouse buttons do nothing), and the
 * Tailed Beast Bomb on right-click in the chakra cloak.
 */
@Mod.EventBusSubscriber(modid = ShinobiArts.MODID, bus = Mod.EventBusSubscriber.Bus.FORGE, value = Dist.CLIENT)
public final class JinchurikiClient {
    /** Where the beast wanders when there's no one to go for. */
    private static float wander;

    private JinchurikiClient() {}

    private static boolean raging() {
        NinjaData d = ClientNinjaData.get();
        return d.isInitialized() && d.jin.rage();
    }

    @SubscribeEvent
    public static void onClientTick(TickEvent.ClientTickEvent event) {
        if (event.phase != TickEvent.Phase.END) return;
        Minecraft mc = Minecraft.getInstance();
        LocalPlayer player = mc.player;
        if (player == null || mc.level == null) return;
        while (KeyBinds.TAILED_BEAST.consumeClick()) {
            ModNetwork.toServer(new ActionPacket(ActionPacket.TAILED_BEAST, 0, player.isShiftKeyDown() ? 1 : 0));
        }
        if (!raging() || mc.isPaused()) return;
        // the beast turns the body toward its prey
        LivingEntity target = Jinchuriki.nearest(player, 24);
        float yaw, pitch;
        if (target != null) {
            Vec3 to = target.getEyePosition().subtract(player.getEyePosition());
            yaw = (float) Math.toDegrees(Math.atan2(-to.x, to.z));
            pitch = (float) -Math.toDegrees(Math.atan2(to.y, Math.sqrt(to.x * to.x + to.z * to.z)));
        } else {
            wander += (player.getRandom().nextFloat() - 0.5f) * 14f;
            yaw = player.getYRot() + Mth.clamp(Mth.wrapDegrees(wander - player.getYRot()), -6f, 6f);
            pitch = 5f;
        }
        float dy = Mth.wrapDegrees(yaw - player.getYRot());
        player.setYRot(player.getYRot() + Mth.clamp(dy, -28f, 28f));
        player.setXRot(Mth.clamp(player.getXRot() + Mth.clamp(pitch - player.getXRot(), -15f, 15f), -60f, 60f));
        player.setYHeadRot(player.getYRot());
        if (target == null) wander = player.getYRot() + Mth.wrapDegrees(wander - player.getYRot());
        player.setSprinting(true);
    }

    /** In a rage form the beast moves the body, not you. */
    @SubscribeEvent(priority = EventPriority.HIGH)
    public static void onMovementInput(MovementInputUpdateEvent event) {
        Minecraft mc = Minecraft.getInstance();
        if (event.getEntity() != mc.player || mc.player == null || !raging()) return;
        LocalPlayer player = mc.player;
        Input in = event.getInput();
        LivingEntity target = Jinchuriki.nearest(player, 24);
        float t = player.tickCount;
        in.shiftKeyDown = false;
        in.down = false;
        if (target != null) {
            double dist = player.distanceTo(target);
            in.forwardImpulse = dist > 2.2 ? 1f : 0.25f;
            in.leftImpulse = dist > 2.2 ? 0f : Mth.sin(t * 0.15f) * 0.8f;      // circling and lunging up close
            in.jumping = player.horizontalCollision || target.getY() > player.getY() + 0.8 || (dist > 4 && dist < 9 && player.onGround());
        } else {
            in.forwardImpulse = 0.7f;
            in.leftImpulse = 0f;
            in.jumping = player.horizontalCollision;
        }
        in.up = in.forwardImpulse > 0;
        in.left = in.leftImpulse > 0;
        in.right = in.leftImpulse < 0;
    }

    /** Raging: clicks do nothing (the beast strikes on its own). In the cloak: right-click fires a Tailed Beast Bomb. */
    @SubscribeEvent(priority = EventPriority.HIGH)
    public static void onInteractionKey(InputEvent.InteractionKeyMappingTriggered event) {
        Minecraft mc = Minecraft.getInstance();
        if (mc.player == null) return;
        if (raging()) {
            event.setSwingHand(false);
            event.setCanceled(true);
            return;
        }
        NinjaData d = ClientNinjaData.get();
        if (d.isInitialized() && d.jin.form == Jinchuriki.CLOAK && event.isUseItem() && event.getHand() == InteractionHand.MAIN_HAND
                && mc.player.getMainHandItem().isEmpty()) {
            ModNetwork.toServer(new ActionPacket(ActionPacket.BEAST_BOMB));
            event.setSwingHand(true);
            event.setCanceled(true);
        }
    }
}
