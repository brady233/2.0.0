package com.shinobiarts.client;

import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.blaze3d.vertex.VertexConsumer;
import com.mojang.math.Axis;
import com.shinobiarts.ShinobiArts;
import com.shinobiarts.entity.MajesticFlame;
import net.minecraft.client.renderer.LightTexture;
import net.minecraft.client.renderer.MultiBufferSource;
import net.minecraft.client.renderer.RenderType;
import net.minecraft.client.renderer.culling.Frustum;
import net.minecraft.client.renderer.entity.EntityRenderer;
import net.minecraft.client.renderer.entity.EntityRendererProvider;
import net.minecraft.client.renderer.texture.OverlayTexture;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.util.Mth;
import net.minecraft.world.phys.Vec3;
import org.joml.Matrix3f;
import org.joml.Matrix4f;

/**
 * Majestic Destroyer Flame: the jet from the mouth (small puffs), then a towering wall of upright flame tongues
 * (flame_tongues.png: four flickering frames, turned to face you about the vertical only, so they lick upward instead
 * of churning like explosions) rolling forward and spreading out, with a lower sea of fire left burning behind it
 * that dies down.
 */
public class MajesticFlameRenderer extends EntityRenderer<MajesticFlame> {
    private static final ResourceLocation TEXTURE = new ResourceLocation(ShinobiArts.MODID, "textures/entity/jutsu/flame_billow.png");
    private static final ResourceLocation TONGUES = new ResourceLocation(ShinobiArts.MODID, "textures/entity/jutsu/flame_tongues.png");

    public MajesticFlameRenderer(EntityRendererProvider.Context context) {
        super(context);
    }

    @Override
    public boolean shouldRender(MajesticFlame entity, Frustum frustum, double x, double y, double z) {
        return frustum.isVisible(entity.getBoundingBoxForCulling());
    }

    @Override
    public void render(MajesticFlame e, float yaw, float partial, PoseStack ps, MultiBufferSource buffers, int light) {
        float age = e.tickCount + partial;
        float scale = e.getScale();
        int life = e.lifetime();
        if (age > life) return;
        Vec3 fwd = e.forward(), side = e.side();
        float front = MajesticFlame.frontDistance(age, scale);
        float fade = Mth.clamp((life - age) / (MajesticFlame.LINGER * 0.8f), 0f, 1f);   // everything dies down at the end
        int seed = e.getId() * 7919;

        if (age < MajesticFlame.JET + 3) {
            // the jet: a narrow stream of fire from the mouth, thickening as it goes
            VertexConsumer vc = buffers.getBuffer(RenderType.entityTranslucentEmissive(TEXTURE));
            float jetFade = age < MajesticFlame.JET ? 1f : 1f - (age - MajesticFlame.JET) / 3f;
            float len = Math.min(6f, front);
            for (float t = 0.3f; t < len; t += 0.3f) {
                float s = 0.3f + t * 0.13f;
                Vec3 p = fwd.scale(t).add(0, 1.5 - t * 0.04, 0);
                puff(ps, vc, p, s, age * 9f + t * 40f, (int) (t * 3 + seed) & 3, jetFade);
            }
        }
        if (age < MajesticFlame.JET) return;

        float camYaw = this.entityRenderDispatcher.camera.getYRot() * Mth.DEG_TO_RAD;
        Vec3 right = new Vec3(Mth.cos(camYaw), 0, Mth.sin(camYaw));
        VertexConsumer vc = buffers.getBuffer(RenderType.entityTranslucentEmissive(TONGUES));
        Matrix4f pose = ps.last().pose();
        Matrix3f normal = ps.last().normal();

        // the sea of fire left behind the front: lower flames, burning down
        for (float d = 2.5f; d < front - 2.5f; d += 2.0f) {
            float passed = age - MajesticFlame.ticksToReach(d);
            float burn = Mth.clamp(1f - passed / (MajesticFlame.LINGER + 25f), 0f, 1f) * fade;
            if (burn <= 0.02f) continue;
            float hw = MajesticFlame.halfWidth(d, scale);
            int cols = Math.max(1, (int) (hw * 2 / 1.7f));
            for (int j = 0; j <= cols; j++) {
                int h = hash(seed, (int) (d * 10), j);
                float l = -hw + 2 * hw * j / cols + ((h & 255) / 255f - 0.5f) * 1.2f;
                float jz = (((h >> 8) & 255) / 255f - 0.5f) * 1.4f;
                float height = (1.3f + ((h >> 16) & 255) / 255f * 1.8f) * (0.35f + 0.65f * burn) * Math.min(1f, scale + 0.3f);
                Vec3 base = fwd.scale(d + jz).add(side.scale(l));
                tongue(vc, pose, normal, base, right, height, age, h, burn);
            }
        }

        // the front: a towering wall of fire, two rows deep, the middle a little ahead of the ends
        float burst = Mth.clamp((age - MajesticFlame.JET) / 4f, 0f, 1f);       // it surges up out of the jet
        for (int row = 1; row >= 0; row--) {                                     // back row first
            float dist = front - row * 1.6f;
            if (dist < 1f) continue;
            float rhw = MajesticFlame.halfWidth(dist, scale), rh = MajesticFlame.height(dist, scale) * burst;
            int cols = Math.max(2, (int) (rhw * 2 / 1.15f));
            for (int j = 0; j <= cols; j++) {
                int h = hash(seed + row * 31, j, 7);
                float u = -1f + 2f * j / cols;
                float l = u * rhw + ((h & 255) / 255f - 0.5f) * 0.8f;
                float f = dist - 0.18f * rhw * u * u + (((h >> 8) & 255) / 255f - 0.5f) * 0.8f;
                float colH = rh * (1f - 0.4f * u * u) * (0.75f + ((h >> 16) & 255) / 255f * 0.5f) * (row == 0 ? 1f : 0.85f);
                colH *= 1f + 0.08f * Mth.sin(age * 0.6f + j * 1.9f);           // the flames rise and fall
                Vec3 base = fwd.scale(f).add(side.scale(l));
                tongue(vc, pose, normal, base, right, Math.max(1.2f, colH * 1.25f), age, h, fade);
            }
        }
        super.render(e, yaw, partial, ps, buffers, light);
    }

    /**
     * One upright tongue of flame standing on {@code base}, {@code height} tall, turned (about the vertical only)
     * to face you, flickering through the texture's four frames.
     */
    private static void tongue(VertexConsumer vc, Matrix4f pose, Matrix3f normal, Vec3 base, Vec3 right, float height, float age,
                               int h, float alpha) {
        if (alpha <= 0.01f || height <= 0.05f) return;
        float w = height * 0.32f;
        int frame = ((int) (age * 0.45f) + (h & 3)) & 3;
        float u0 = frame * 0.25f, u1 = u0 + 0.25f;
        if (((h >> 3) & 1) == 1) {                                               // mirrored half the time
            float t = u0;
            u0 = u1;
            u1 = t;
        }
        int a = Math.round(255 * Mth.clamp(alpha, 0f, 1f));
        Vec3 r = right.scale(w);
        float y0 = (float) base.y - 0.25f, y1 = (float) base.y + height;
        tv(vc, pose, normal, (float) (base.x - r.x), y0, (float) (base.z - r.z), u0, 1f, a);
        tv(vc, pose, normal, (float) (base.x + r.x), y0, (float) (base.z + r.z), u1, 1f, a);
        tv(vc, pose, normal, (float) (base.x + r.x), y1, (float) (base.z + r.z), u1, 0f, a);
        tv(vc, pose, normal, (float) (base.x - r.x), y1, (float) (base.z - r.z), u0, 0f, a);
    }

    private static void tv(VertexConsumer vc, Matrix4f pose, Matrix3f normal, float x, float y, float z, float u, float v, int alpha) {
        vc.vertex(pose, x, y, z).color(255, 255, 255, alpha).uv(u, v).overlayCoords(OverlayTexture.NO_OVERLAY)
                .uv2(LightTexture.FULL_BRIGHT).normal(normal, 0f, 1f, 0f).endVertex();
    }

    /** One flame puff at {@code p} (relative to the entity), {@code size} blocks across, turned to the camera. */
    private void puff(PoseStack ps, VertexConsumer vc, Vec3 p, float size, float spin, int variant, float alpha) {
        if (alpha <= 0.01f || size <= 0.01f) return;
        ps.pushPose();
        ps.translate(p.x, p.y, p.z);
        ps.mulPose(this.entityRenderDispatcher.cameraOrientation());
        ps.mulPose(Axis.YP.rotationDegrees(180f));
        ps.mulPose(Axis.ZP.rotationDegrees(spin));
        ps.scale(size, size, size);
        PoseStack.Pose pose = ps.last();
        float u0 = (variant & 1) * 0.5f, v0 = (variant >> 1) * 0.5f;
        int a = Math.round(255 * Mth.clamp(alpha, 0f, 1f));
        vertex(vc, pose.pose(), pose.normal(), -0.5f, -0.5f, u0, v0 + 0.5f, a);
        vertex(vc, pose.pose(), pose.normal(), 0.5f, -0.5f, u0 + 0.5f, v0 + 0.5f, a);
        vertex(vc, pose.pose(), pose.normal(), 0.5f, 0.5f, u0 + 0.5f, v0, a);
        vertex(vc, pose.pose(), pose.normal(), -0.5f, 0.5f, u0, v0, a);
        ps.popPose();
    }

    private static void vertex(VertexConsumer vc, Matrix4f pose, Matrix3f normal, float x, float y, float u, float v, int alpha) {
        vc.vertex(pose, x, y, 0f).color(255, 255, 255, alpha).uv(u, v).overlayCoords(OverlayTexture.NO_OVERLAY)
                .uv2(LightTexture.FULL_BRIGHT).normal(normal, 0f, 1f, 0f).endVertex();
    }

    private static int hash(int a, int b, int c) {
        int h = a * 73856093 ^ b * 19349663 ^ c * 83492791;
        h ^= h >>> 13;
        h *= 0x5bd1e995;
        h ^= h >>> 15;
        return h & 0x7fffffff;
    }

    @Override
    public ResourceLocation getTextureLocation(MajesticFlame entity) {
        return TEXTURE;
    }
}
