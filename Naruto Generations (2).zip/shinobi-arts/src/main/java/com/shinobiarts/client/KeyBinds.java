package com.shinobiarts.client;

import com.mojang.blaze3d.platform.InputConstants;
import net.minecraft.client.KeyMapping;
import net.minecraftforge.client.settings.KeyConflictContext;
import org.lwjgl.glfw.GLFW;

/**
 * Default keys; players can rebind them under Options > Controls > Naruto Generations.
 * Ninja Jump uses the vanilla Sneak + Jump keys, so it follows whatever those are bound to.
 */
public final class KeyBinds {
    public static final String CATEGORY = "key.categories.shinobiarts";

    public static final KeyMapping NEXT = key("next", GLFW.GLFW_KEY_G);
    public static final KeyMapping PREV = key("prev", GLFW.GLFW_KEY_H);
    /** The Sharingan: each press goes a step further (tomoe, Mangekyou, Eternal) and then off. */
    public static final KeyMapping DOJUTSU = key("dojutsu", GLFW.GLFW_KEY_V);
    public static final KeyMapping BYAKUGAN = key("byakugan", GLFW.GLFW_KEY_X);
    public static final KeyMapping RINNEGAN = key("rinnegan", GLFW.GLFW_KEY_C);
    public static final KeyMapping CHARGE = key("charge", GLFW.GLFW_KEY_Z);
    public static final KeyMapping SAGE = key("sage", GLFW.GLFW_KEY_B);
    public static final KeyMapping STATS = key("stats", GLFW.GLFW_KEY_J);
    // eye techniques of an active Sharingan (Amaterasu, Kamui, Genjutsu...): see ninja/EyeTechniques
    public static final KeyMapping JUTSU_1 = key("jutsu_1", GLFW.GLFW_KEY_R);
    public static final KeyMapping JUTSU_2 = key("jutsu_2", GLFW.GLFW_KEY_Y);
    public static final KeyMapping JUTSU_3 = key("jutsu_3", GLFW.GLFW_KEY_U);
    // toggles
    public static final KeyMapping SUBSTITUTION = key("substitution", GLFW.GLFW_KEY_K);
    public static final KeyMapping CHAKRA_CONTROL = key("chakra_control", GLFW.GLFW_KEY_N);
    public static final KeyMapping EIGHT_GATES = key("eight_gates", GLFW.GLFW_KEY_I);
    // Susanoo: summon / grow a stage; Sneak + key releases it
    public static final KeyMapping SUSANOO = key("susanoo", GLFW.GLFW_KEY_O);

    // Jinchuriki: the beast's rage forms, then (once tamed) its chakra cloak
    public static final KeyMapping TAILED_BEAST = key("tailed_beast", GLFW.GLFW_KEY_M);

    public static final KeyMapping[] ALL = {NEXT, PREV, DOJUTSU, BYAKUGAN, RINNEGAN, CHARGE, SAGE, STATS, JUTSU_1, JUTSU_2, JUTSU_3, SUBSTITUTION, CHAKRA_CONTROL, EIGHT_GATES, SUSANOO, TAILED_BEAST};
    public static final KeyMapping[] JUTSU_KEYS = {JUTSU_1, JUTSU_2, JUTSU_3};

    private static KeyMapping key(String name, int keyCode) {
        return new KeyMapping("key.shinobiarts." + name, KeyConflictContext.IN_GAME, InputConstants.Type.KEYSYM, keyCode, CATEGORY);
    }

    private KeyBinds() {}
}
