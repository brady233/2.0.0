package com.shinobiarts.client.fx;

import com.mojang.blaze3d.vertex.VertexConsumer;
import net.minecraft.util.Mth;
import net.minecraft.util.RandomSource;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.phys.Vec3;

/** The ninja tools' effects: a smoke bomb's cloud and a wire trap's wire wound round whoever it caught. */
final class FxTools {
    private FxTools() {}

    /** A smoke bomb's cloud (a = where it burst, size = its radius): thick grey smoke billowing out and hanging there. */
    static void smoke(FxClient.Ctx c) {
        float age = c.age();
        Vec3 centre = c.fx().a;
        float radius = c.fx().size;
        float fade = Mth.clamp(age / 6f, 0f, 1f) * (1f - Mth.clamp((age - (c.fx().ticks - 30)) / 30f, 0f, 1f));
        if (fade <= 0) return;
        VertexConsumer smoke = FxDraw.litTex(c.buffers(), FxYin.PUFF);
        RandomSource r = FxDraw.rng(c.fx().seed, 57);
        float spread = Mth.clamp(0.25f + age / 12f, 0.25f, 1f);
        int light = FxDraw.lightAt(centre.add(0, 1, 0));
        for (int k = 0; k < 70; k++) {
            double a = r.nextFloat() * Math.PI * 2, d = Math.sqrt(r.nextFloat()) * radius * spread;
            double rise = r.nextFloat() * radius * 0.9 * spread;
            double drift = age * 0.01 * (r.nextFloat() - 0.5);
            Vec3 p = centre.add(Math.cos(a + drift) * d, 0.3 + rise + Mth.sin(age * 0.05f + k) * 0.15, Math.sin(a + drift) * d);
            float s = (2.5f + r.nextFloat() * 2.5f) * (0.6f + 0.4f * spread);
            int w = 92 + r.nextInt(50);
            FxDraw.billboard(smoke, c.ps(), c.camera(), p, s, s, r.nextFloat() * 6 + age * 0.01f,
                    new FxDraw.Paint(0, 0, 1, 1, w, w, w + 4, Math.round(225 * fade)), light);
        }
    }

    /** A wire trap sprung (entityA caught, size = its width): loops of steel wire pulled tight round its body. */
    static void wireBind(FxClient.Ctx c) {
        Entity e = c.fx().entityA();
        if (e == null) return;
        Vec3 base = e.getPosition(c.partial());
        float h = e.getBbHeight(), w = c.fx().size * 0.62f;
        float tighten = Mth.clamp(c.age() / 5f, 0f, 1f);
        float fade = 1f - Mth.clamp((c.age() - (c.fx().ticks - 6)) / 6f, 0f, 1f);
        VertexConsumer vc = FxDraw.lit(c.buffers());
        int light = FxDraw.lightAt(base.add(0, h / 2, 0));
        FxDraw.Paint steel = FxDraw.color(0xC8CCD6, 0.9f * fade);
        for (int k = 0; k < 5; k++) {
            float y = h * (0.2f + 0.15f * k);
            float r = w * (1.8f - 0.8f * tighten) * (k == 2 ? 0.92f : 1f);
            float tilt = (k - 2) * 0.12f;
            FxDraw.ring(vc, c.ps(), base.add(0, y, 0), new Vec3(tilt, 1, -tilt * 0.5), r, 0.03f, 24, steel, steel, light);
        }
    }
}
