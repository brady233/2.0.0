package com.shinobiarts.client.fx;

import com.mojang.blaze3d.vertex.VertexConsumer;
import com.shinobiarts.ShinobiArts;
import com.shinobiarts.client.fx.FxDraw.Paint;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.util.Mth;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.phys.Vec3;

import java.util.ArrayList;
import java.util.List;

/**
 * Sealing (the Uzumaki): a violet barrier box covered in seal script (Barrier), golden chakra chains shooting from
 * the caster's back and wrapping the target (Adamantine Sealing Chains), and the five-pronged seal burning on the
 * target's body (Five Elements Seal).
 */
final class FxSeal {
    static final ResourceLocation BARRIER = new ResourceLocation(ShinobiArts.MODID, "textures/entity/jutsu/barrier.png");
    static final ResourceLocation SEAL = new ResourceLocation(ShinobiArts.MODID, "textures/entity/jutsu/five_seal.png");
    private static final int GOLD = 0xFFC93C;

    private FxSeal() {}

    /** Barrier: a glowing violet box round the caster, its walls covered in drifting seal script. */
    static void barrier(FxClient.Ctx c) {
        Entity e = c.fx().entityA();
        Vec3 feet = e != null ? e.getPosition(c.partial()) : c.fx().a;
        float age = c.age();
        float fade = Mth.clamp(age / 5f, 0f, 1f) * (1f - Mth.clamp((age - (c.fx().ticks - 8)) / 8f, 0f, 1f));
        float r = c.fx().size, h = 3.6f;
        VertexConsumer vc = FxDraw.glowTex(c.buffers(), BARRIER);
        float scroll = age * 0.01f;
        Paint wall = new Paint(0, 0, 1, 1, 255, 255, 255, Math.round(150 * fade));
        Vec3[] corners = {feet.add(-r, 0, -r), feet.add(r, 0, -r), feet.add(r, 0, r), feet.add(-r, 0, r)};
        for (int i = 0; i < 4; i++) {
            Vec3 a = corners[i], b = corners[(i + 1) % 4];
            FxDraw.quadUv(vc, c.ps(), a.add(0, -0.1, 0), a.add(0, h, 0), b.add(0, h, 0), b.add(0, -0.1, 0), 0, scroll + 2, 2 * r / 2f, scroll, wall, FxDraw.FULL);
        }
        FxDraw.quadUv(vc, c.ps(), corners[0].add(0, h, 0), corners[1].add(0, h, 0), corners[2].add(0, h, 0), corners[3].add(0, h, 0),
                0, 0, r, r, wall, FxDraw.FULL);
        // bright edges
        VertexConsumer add = FxDraw.additive(c.buffers());
        for (int i = 0; i < 4; i++) {
            Vec3 a = corners[i], b = corners[(i + 1) % 4];
            FxDraw.ribbon(add, c.ps(), c.cam(), List.of(a, a.add(0, h, 0)), 0.08f, 0f, FxDraw.addColor(0xE2B6FF, fade), FxDraw.addColor(0xE2B6FF, fade), FxDraw.FULL);
            FxDraw.ribbon(add, c.ps(), c.cam(), List.of(a.add(0, h, 0), b.add(0, h, 0)), 0.08f, 0f, FxDraw.addColor(0xE2B6FF, fade), FxDraw.addColor(0xE2B6FF, fade), FxDraw.FULL);
            FxDraw.ribbon(add, c.ps(), c.cam(), List.of(a.add(0, 0.02, 0), b.add(0, 0.02, 0)), 0.08f, 0f, FxDraw.addColor(0xE2B6FF, fade), FxDraw.addColor(0xE2B6FF, fade), FxDraw.FULL);
        }
    }

    /** One chain: links along a path, each turned a quarter from the last, glowing gold. */
    private static void chain(VertexConsumer vc, FxClient.Ctx c, List<Vec3> path, float alpha) {
        Paint gold = FxDraw.color(GOLD, alpha);
        Paint light = FxDraw.color(0xFFF1B8, alpha);
        float linkLen = 0.34f;
        double carry = 0;
        int index = 0;
        for (int i = 0; i + 1 < path.size(); i++) {
            Vec3 a = path.get(i), b = path.get(i + 1);
            double seg = a.distanceTo(b);
            if (seg < 1e-6) continue;
            Vec3 dir = b.subtract(a).normalize();
            Vec3 n = FxDraw.perpendicular(dir), m = dir.cross(n);
            for (double d = carry; d < seg; d += linkLen) {
                Vec3 centre = a.add(dir.scale(d));
                Vec3 w = (index++ % 2 == 0 ? n : m).scale(0.1);
                Vec3 t = (index % 2 == 0 ? m : n).scale(0.025);
                Vec3 half = dir.scale(linkLen * 0.55f);
                // a link: two long sides and two short ends
                FxDraw.box(vc, c.ps(), centre.add(w), half, w.normalize().scale(0.03), t, gold, FxDraw.FULL);
                FxDraw.box(vc, c.ps(), centre.subtract(w), half, w.normalize().scale(0.03), t, gold, FxDraw.FULL);
                FxDraw.box(vc, c.ps(), centre.add(half), dir.scale(0.03), w, t, light, FxDraw.FULL);
                FxDraw.box(vc, c.ps(), centre.subtract(half), dir.scale(0.03), w, t, light, FxDraw.FULL);
                carry = d + linkLen - seg;
            }
        }
    }

    /**
     * Adamantine Sealing Chains: three golden chains burst from the caster's back, arc over to the target and coil
     * round it.
     */
    static void chains(FxClient.Ctx c) {
        Entity caster = c.fx().entityA(), target = c.fx().entityB();
        if (caster == null || target == null) return;
        float age = c.age();
        float fade = 1f - Mth.clamp((age - (c.fx().ticks - 8)) / 8f, 0f, 1f);
        float reach = FxDraw.smooth(age / 6f);
        float yaw = (caster instanceof LivingEntity l ? Mth.rotLerp(c.partial(), l.yBodyRotO, l.yBodyRot) : caster.getYRot()) * Mth.DEG_TO_RAD;
        Vec3 fwd = new Vec3(-Mth.sin(yaw), 0, Mth.cos(yaw)), right = new Vec3(-Mth.cos(yaw), 0, -Mth.sin(yaw));
        Vec3 back = caster.getPosition(c.partial()).add(0, caster.getBbHeight() * 0.72, 0).subtract(fwd.scale(0.25));
        Vec3 tmid = target.getPosition(c.partial()).add(0, target.getBbHeight() * 0.55, 0);
        VertexConsumer vc = FxDraw.glow(c.buffers());
        for (int k = 0; k < 3; k++) {
            Vec3 start = back.add(right.scale((k - 1) * 0.25)).add(0, k == 1 ? 0.15 : 0, 0);
            Vec3 lift = new Vec3(0, 1.4 + k * 0.4, 0).add(right.scale((k - 1) * 1.2));
            List<Vec3> path = new ArrayList<>();
            for (int i = 0; i <= 16; i++) {
                float t = i / 16f;
                Vec3 p = start.lerp(tmid, t).add(lift.scale(4 * t * (1 - t)));
                p = p.add(0, 0.08 * Mth.sin(age * 0.6f + i * 0.8f + k), 0);      // straining
                path.add(p);
            }
            chain(vc, c, FxWood.grow(path, reach), fade);
        }
        if (reach >= 1f) {                                   // wrapped round the target
            List<Vec3> coil = new ArrayList<>();
            Vec3 feet = target.getPosition(c.partial());
            float r = target.getBbWidth() * 0.6f + 0.25f;
            for (int i = 0; i <= 40; i++) {
                float t = i / 40f;
                float ang = t * Mth.TWO_PI * 3f;
                coil.add(feet.add(Mth.cos(ang) * r, 0.3 + t * target.getBbHeight() * 0.7, Mth.sin(ang) * r));
            }
            chain(vc, c, FxWood.grow(coil, FxDraw.smooth((age - 6f) / 6f)), fade);
        }
    }

    /**
     * Five Elements Seal: five blue flames on the caster's fingertips as the hand strikes, then the five-pronged seal
     * burning on the target's stomach while its chakra stays sealed.
     */
    static void fiveSeal(FxClient.Ctx c) {
        Entity target = c.fx().entityA(), caster = c.fx().entityB();
        float age = c.age();
        VertexConsumer add = FxDraw.additive(c.buffers());
        if (caster != null && age < 12) {
            Vec3 h = FxLightning.hand(caster, c.partial(), true);
            float f = 1f - age / 12f;
            for (int k = 0; k < 5; k++) {
                Vec3 tip = h.add((k - 2) * 0.07, 0.12 + Math.abs(k - 2) * -0.02, 0);
                FxDraw.billboard(add, c.ps(), c.camera(), tip.add(0, 0.08, 0), 0.12f, 0.24f, 0, FxDraw.addColor(0x6AA8FF, f), FxDraw.FULL);
            }
        }
        if (target == null || age < 6) return;
        float fade = Mth.clamp((age - 6f) / 3f, 0f, 1f) * (1f - Mth.clamp((age - (c.fx().ticks - 15)) / 15f, 0f, 1f));
        float yaw = (target instanceof LivingEntity l ? Mth.rotLerp(c.partial(), l.yBodyRotO, l.yBodyRot) : target.getYRot()) * Mth.DEG_TO_RAD;
        Vec3 fwd = new Vec3(-Mth.sin(yaw), 0, Mth.cos(yaw)), right = new Vec3(-Mth.cos(yaw), 0, -Mth.sin(yaw));
        Vec3 centre = target.getPosition(c.partial()).add(0, target.getBbHeight() * 0.5, 0).add(fwd.scale(target.getBbWidth() * 0.5 + 0.03));
        float s = target.getBbWidth() * 0.55f + 0.05f;
        float flash = age < 10 ? 1f + (10 - age) * 0.15f : 1f;
        float pulse = 0.85f + 0.15f * Mth.sin(age * 0.3f);
        Paint p = new Paint(0, 0, 1, 1, Math.round(255 * fade * pulse), Math.round(255 * fade * pulse), Math.round(255 * fade * pulse), 255);
        VertexConsumer vc = c.buffers().getBuffer(net.minecraft.client.renderer.RenderType.eyes(SEAL));
        Vec3 x = right.scale(s * flash), y = new Vec3(0, s * flash, 0);
        FxDraw.quadUv(vc, c.ps(), centre.subtract(x).subtract(y), centre.subtract(x).add(y), centre.add(x).add(y), centre.add(x).subtract(y),
                0, 1, 1, 0, p, FxDraw.FULL);
    }
}
