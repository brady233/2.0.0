package com.shinobiarts.client.fx;

import com.mojang.blaze3d.vertex.VertexConsumer;
import com.shinobiarts.ShinobiArts;
import com.shinobiarts.client.fx.FxDraw.Paint;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.util.Mth;
import net.minecraft.util.RandomSource;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.phys.Vec3;

import java.util.List;

/**
 * Magnet Release (the Third Kazekage's iron sand): a churning black cloud raining needles (Drizzle), sand closing in
 * round the target into a crushing shell (Coffin), and a sphere of sand that bursts into branching spikes in every
 * direction (World Method).
 */
final class FxMagnet {
    static final ResourceLocation SAND = new ResourceLocation(ShinobiArts.MODID, "textures/entity/jutsu/iron_sand.png");
    private static final int IRON = 0x1C1C24;

    private FxMagnet() {}

    private static Paint grain(float alpha) {
        return new Paint(0, 0, 1, 1, 255, 255, 255, Math.round(255 * Mth.clamp(alpha, 0f, 1f)));
    }

    /** Iron Sand Drizzle: a black cloud churns overhead and hard needles of sand rain out of it. */
    static void rain(FxClient.Ctx c) {
        Vec3 centre = c.fx().a;
        float age = c.age();
        float fade = Mth.clamp(age / 4f, 0f, 1f) * (1f - Mth.clamp((age - (c.fx().ticks - 6)) / 6f, 0f, 1f));
        VertexConsumer sand = FxDraw.litTex(c.buffers(), SAND);
        RandomSource r = FxDraw.rng(c.fx().seed, 8);
        Vec3 cloud = centre.add(0, 6, 0);
        int light = FxDraw.lightAt(cloud);
        for (int k = 0; k < 40; k++) {
            float ang = r.nextFloat() * Mth.TWO_PI + age * 0.05f * (k % 2 == 0 ? 1 : -1), dist = r.nextFloat() * 2.8f;
            Vec3 p = cloud.add(Mth.cos(ang) * dist, r.nextGaussian() * 0.35, Mth.sin(ang) * dist);
            float s = 0.7f + r.nextFloat() * 0.9f;
            FxDraw.billboard(sand, c.ps(), c.camera(), p, s, s, r.nextFloat() * 6 + age * 0.05f, grain(0.9f * fade), light);
        }
        VertexConsumer vc = FxDraw.lit(c.buffers());
        for (int k = 0; k < 26; k++) {
            float x = (r.nextFloat() - 0.5f) * 5f, z = (r.nextFloat() - 0.5f) * 5f;
            float y = 6f - ((age * 1.6f + r.nextFloat() * 6f) % 6f);
            Vec3 tip = centre.add(x, y, z);
            FxDraw.ribbon(vc, c.ps(), c.cam(), List.of(tip.add(0, 0.7, 0), tip), 0.07f, 0.7f, FxDraw.color(IRON, 0.9f * fade),
                    FxDraw.color(IRON, 0.9f * fade), light);
        }
    }

    /** Iron Sand Coffin: sand swirls in from all round, closes into a shell over the target, crushes, then bursts. */
    static void coffin(FxClient.Ctx c) {
        Entity e = c.fx().entityA();
        Vec3 mid = e != null ? e.getPosition(c.partial()).add(0, e.getBbHeight() / 2, 0) : c.fx().a;
        float hull = e != null ? Math.max(e.getBbWidth(), e.getBbHeight()) * 0.62f + 0.25f : 1.3f;
        float age = c.age();
        int ticks = c.fx().ticks;
        float gather = FxDraw.smooth(age / 18f);
        float crush = age > ticks - 6 ? 1f - 0.18f * FxDraw.smooth((age - (ticks - 6)) / 2f) : 1f;
        float burst = Mth.clamp((age - (ticks - 4)) / 4f, 0f, 1f);
        VertexConsumer sand = FxDraw.litTex(c.buffers(), SAND);
        RandomSource r = FxDraw.rng(c.fx().seed, 9);
        int light = FxDraw.lightAt(mid);
        for (int k = 0; k < 90; k++) {
            Vec3 dir = new Vec3(r.nextGaussian(), r.nextGaussian() * 0.8, r.nextGaussian()).normalize();
            float spin = age * 0.15f * (k % 2 == 0 ? 1 : -1);
            Vec3 d = new Vec3(dir.x * Mth.cos(spin) - dir.z * Mth.sin(spin), dir.y, dir.x * Mth.sin(spin) + dir.z * Mth.cos(spin));
            float dist = Mth.lerp(gather, 2.8f + r.nextFloat(), hull * (0.9f + r.nextFloat() * 0.15f)) * crush + burst * (2f + r.nextFloat() * 2f);
            Vec3 p = mid.add(d.scale(dist));
            float s = 0.55f + r.nextFloat() * 0.5f;
            FxDraw.billboard(sand, c.ps(), c.camera(), p, s, s, r.nextFloat() * 6, grain(Mth.clamp(0.3f + gather, 0f, 1f) * (1f - burst)), light);
        }
        if (gather > 0.85f && burst <= 0f) {           // the shell once it has closed
            FxDraw.sphere(FxDraw.lit(c.buffers()), c.ps(), mid, hull * crush * 0.97f, 10, 16, FxDraw.color(IRON, 0.85f * (gather - 0.85f) / 0.15f), light);
        }
    }

    /** Iron Sand World Method: a sphere of sand gathers, then bursts into long branching spikes in every direction. */
    static void world(FxClient.Ctx c) {
        Vec3 centre = c.fx().a;
        float age = c.age();
        int ticks = c.fx().ticks;
        float gather = FxDraw.smooth(age / 12f);
        float shoot = FxDraw.smooth((age - 12f) / 4f);
        float crumble = Mth.clamp((age - (ticks - 8)) / 8f, 0f, 1f);
        int light = FxDraw.lightAt(centre);
        VertexConsumer vc = FxDraw.lit(c.buffers());
        Paint iron = FxDraw.color(IRON, 1f - crumble * 0.9f);
        FxDraw.sphere(vc, c.ps(), centre, 1.2f * gather * (1f - crumble * 0.5f), 10, 16, iron, light);
        VertexConsumer sand = FxDraw.litTex(c.buffers(), SAND);
        RandomSource g = FxDraw.rng(c.fx().seed, 10);
        if (age < 13) {
            for (int k = 0; k < 40; k++) {                 // sand streaming in
                Vec3 d = new Vec3(g.nextGaussian(), g.nextGaussian(), g.nextGaussian()).normalize();
                float dist = Mth.lerp(gather, 4f + g.nextFloat() * 2f, 1.2f);
                FxDraw.billboard(sand, c.ps(), c.camera(), centre.add(d.scale(dist)), 0.6f, 0.6f, g.nextFloat() * 6, grain(0.85f), light);
            }
        }
        if (shoot <= 0f) return;
        RandomSource r = FxDraw.rng(c.fx().seed, 11);
        for (int k = 0; k < 34; k++) {
            Vec3 dir = new Vec3(r.nextGaussian(), r.nextGaussian() * 0.7, r.nextGaussian()).normalize();
            float len = (6f + r.nextFloat() * 3f) * shoot * (1f - crumble * 0.4f);
            Vec3 base = centre.add(dir.scale(0.9));
            FxDraw.cone(vc, c.ps(), base, base.add(dir.scale(len)), 0.2f, 6, iron, light);
            for (int b = 0; b < 2; b++) {                  // smaller spikes branching off each one
                float at = 0.35f + b * 0.25f + r.nextFloat() * 0.1f;
                Vec3 from = base.add(dir.scale(len * at));
                Vec3 bd = dir.add(FxDraw.perpendicular(dir).scale(r.nextGaussian() * 0.9)).normalize();
                FxDraw.cone(vc, c.ps(), from, from.add(bd.scale(len * 0.35f)), 0.1f, 5, iron, light);
            }
        }
    }
}
