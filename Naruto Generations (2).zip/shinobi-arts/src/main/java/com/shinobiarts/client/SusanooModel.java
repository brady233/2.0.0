package com.shinobiarts.client;

import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import com.shinobiarts.ShinobiArts;
import net.minecraft.client.Minecraft;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.server.packs.resources.Resource;

import javax.annotation.Nullable;
import java.io.DataInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;

/**
 * The Susanoo meshes and their data, loaded from assets/shinobiarts/susanoo/ (written by tools/make_susanoo.py):
 * stage1-5.bin (bones and pieces, smooth normals) and data.json (materials, keyframed actions). Loaded the first time
 * a stage is drawn and dropped on a resource reload, so a resource pack can replace them.
 */
public final class SusanooModel {
    public static final class Bone {
        public final String name;
        public final int parent;
        public final float px, py, pz;

        Bone(String name, int parent, float px, float py, float pz) {
            this.name = name;
            this.parent = parent;
            this.px = px;
            this.py = py;
            this.pz = pz;
        }
    }

    /** One piece of the mesh: indexed triangles, all on one bone and one material. */
    public static final class Piece {
        public final int bone;
        public final String material;
        public final float[] pos, nrm, uv;
        public final int[] idx;
        /** Where this piece's vertices start in the renderer's per-frame arrays. */
        public int offset;

        Piece(int bone, String material, float[] pos, float[] nrm, float[] uv, int[] idx) {
            this.bone = bone;
            this.material = material;
            this.pos = pos;
            this.nrm = nrm;
            this.uv = uv;
            this.idx = idx;
        }

        public int vertices() {
            return pos.length / 3;
        }
    }

    public static final class Material {
        public final String name, slot, texture;
        public final float opacity;
        public final boolean glowPass;

        Material(String name, String slot, String texture, float opacity, boolean glowPass) {
            this.name = name;
            this.slot = slot;
            this.texture = texture;
            this.opacity = opacity;
            this.glowPass = glowPass;
        }
    }

    /** A keyframed action: key times (ticks) and, per key, each bone's [x, y, z] degrees. */
    public static final class Action {
        public final int length;
        public final int[] times;
        public final List<Map<String, float[]>> poses;

        Action(int length, int[] times, List<Map<String, float[]>> poses) {
            this.length = length;
            this.times = times;
            this.poses = poses;
        }
    }

    public final int stage;
    public final float scale;
    public final Bone[] bones;
    public final Map<String, Integer> boneIndex = new HashMap<>();
    /** Pieces grouped by material, in a fixed order. */
    public final Map<String, List<Piece>> byMaterial = new LinkedHashMap<>();
    public final Map<String, Action> actions = new HashMap<>();
    public Map<String, float[]> blockPose = new HashMap<>();
    public int maxVertices, totalVertices;

    private static final SusanooModel[] STAGES = new SusanooModel[6];
    private static final boolean[] FAILED = new boolean[6];
    private static Map<String, Material> materials;

    private SusanooModel(int stage, float scale, Bone[] bones) {
        this.stage = stage;
        this.scale = scale;
        this.bones = bones;
        for (int i = 0; i < bones.length; i++) boneIndex.put(bones[i].name, i);
    }

    public static Map<String, Material> materials() {
        return materials == null ? Map.of() : materials;
    }

    /** The model of a stage (1-5), or null if it couldn't be read (logged once). */
    @Nullable
    public static synchronized SusanooModel get(int stage) {
        if (stage < 1 || stage > 5) return null;
        if (STAGES[stage] == null && !FAILED[stage]) {
            try {
                JsonObject data = readData();
                STAGES[stage] = load(stage, data);
            } catch (IOException | RuntimeException e) {
                FAILED[stage] = true;
                ShinobiArts.LOGGER.error("Couldn't load the Susanoo model for stage {}", stage, e);
            }
        }
        return STAGES[stage];
    }

    private static final Map<String, SusanooModel> DESIGNED = new HashMap<>();
    private static final java.util.Set<String> DESIGN_FAILED = new java.util.HashSet<>();

    /**
     * A stage as one Mangekyou's Susanoo (stages 3-5): the shared body with that design's hands and weapons
     * (weapons&lt;stage&gt;_&lt;design&gt;.bin) and its own moves. Falls back to the plain stage if they can't be read.
     */
    @Nullable
    public static synchronized SusanooModel get(int stage, String design) {
        SusanooModel base = get(stage);
        if (base == null || stage < 3) return base;
        String key = stage + "_" + design;
        SusanooModel m = DESIGNED.get(key);
        if (m != null) return m;
        if (DESIGN_FAILED.contains(key)) return base;
        try {
            m = withDesign(base, stage, design, readData());
            DESIGNED.put(key, m);
            return m;
        } catch (IOException | RuntimeException e) {
            DESIGN_FAILED.add(key);
            ShinobiArts.LOGGER.error("Couldn't load the {} Susanoo for stage {}", design, stage, e);
            return base;
        }
    }

    private static SusanooModel withDesign(SusanooModel base, int stage, String design, JsonObject data) throws IOException {
        SusanooModel model = new SusanooModel(stage, base.scale, base.bones);
        for (Map.Entry<String, List<Piece>> e : base.byMaterial.entrySet()) {
            List<Piece> list = model.byMaterial.computeIfAbsent(e.getKey(), k -> new ArrayList<>());
            for (Piece p : e.getValue()) list.add(new Piece(p.bone, p.material, p.pos, p.nrm, p.uv, p.idx));
        }
        model.maxVertices = base.maxVertices;
        try (DataInputStream in = new DataInputStream(new java.io.BufferedInputStream(open("susanoo/weapons" + stage + "_" + design + ".bin")))) {
            byte[] magic = new byte[4];
            in.readFully(magic);
            if (magic[0] != 'S' || magic[1] != 'U' || magic[2] != 'S' || magic[3] != 'W') throw new IOException("not a Susanoo weapon set");
            in.readInt(); // version
            int pieces = in.readInt();
            for (int p = 0; p < pieces; p++) {
                String boneName = in.readUTF();
                String mat = in.readUTF();
                int nv = in.readInt(), nt = in.readInt();
                float[] pos = new float[nv * 3], nrm = new float[nv * 3], uv = new float[nv * 2];
                int[] idx = new int[nt * 3];
                for (int i = 0; i < pos.length; i++) pos[i] = in.readFloat();
                for (int i = 0; i < nrm.length; i++) nrm[i] = in.readByte() / 127f;
                for (int i = 0; i < uv.length; i++) uv[i] = in.readFloat();
                for (int i = 0; i < idx.length; i++) idx[i] = nv <= 65535 ? in.readUnsignedShort() : in.readInt();
                Integer bone = model.boneIndex.get(boneName);
                if (bone == null) continue;
                model.byMaterial.computeIfAbsent(mat, k -> new ArrayList<>()).add(new Piece(bone, mat, pos, nrm, uv, idx));
                model.maxVertices = Math.max(model.maxVertices, nv);
            }
        }
        for (List<Piece> list : model.byMaterial.values()) {
            for (Piece piece : list) {
                piece.offset = model.totalVertices;
                model.totalVertices += piece.vertices();
            }
        }
        JsonObject all = data.getAsJsonObject("anims");
        JsonObject anims = all.has(stage + "_" + design) ? all.getAsJsonObject(stage + "_" + design) : all.getAsJsonObject(String.valueOf(stage));
        readActions(model, anims);
        return model;
    }

    /** Forget everything (resource reload). */
    public static synchronized void clear() {
        DESIGNED.clear();
        DESIGN_FAILED.clear();
        for (int i = 0; i < STAGES.length; i++) {
            STAGES[i] = null;
            FAILED[i] = false;
        }
        materials = null;
    }

    private static InputStream open(String path) throws IOException {
        Optional<Resource> res = Minecraft.getInstance().getResourceManager().getResource(new ResourceLocation(ShinobiArts.MODID, path));
        if (res.isEmpty()) throw new IOException("missing " + path);
        return res.get().open();
    }

    private static JsonObject readData() throws IOException {
        try (InputStreamReader r = new InputStreamReader(open("susanoo/data.json"), StandardCharsets.UTF_8)) {
            JsonObject data = JsonParser.parseReader(r).getAsJsonObject();
            if (materials == null) {
                Map<String, Material> mats = new LinkedHashMap<>();
                List<String> glow = new ArrayList<>();
                for (JsonElement g : data.getAsJsonArray("glowPass")) glow.add(g.getAsString());
                for (Map.Entry<String, JsonElement> e : data.getAsJsonObject("materials").entrySet()) {
                    JsonObject m = e.getValue().getAsJsonObject();
                    String tex = m.get("tex").getAsString();
                    mats.put(e.getKey(), new Material(e.getKey(), m.get("slot").getAsString(), tex, m.get("opacity").getAsFloat(), glow.contains(tex)));
                }
                materials = mats;
            }
            return data;
        }
    }

    private static SusanooModel load(int stage, JsonObject data) throws IOException {
        SusanooModel model;
        try (DataInputStream in = new DataInputStream(new java.io.BufferedInputStream(open("susanoo/stage" + stage + ".bin")))) {
            byte[] magic = new byte[4];
            in.readFully(magic);
            if (magic[0] != 'S' || magic[1] != 'U' || magic[2] != 'S' || magic[3] != 'A') throw new IOException("not a Susanoo model");
            in.readInt(); // version
            float scale = in.readFloat();
            Bone[] bones = new Bone[in.readInt()];
            for (int i = 0; i < bones.length; i++) {
                String name = in.readUTF();
                int parent = in.readInt();
                bones[i] = new Bone(name, parent, in.readFloat(), in.readFloat(), in.readFloat());
            }
            model = new SusanooModel(stage, scale, bones);
            int pieces = in.readInt();
            for (int p = 0; p < pieces; p++) {
                int bone = in.readInt();
                String mat = in.readUTF();
                int nv = in.readInt(), nt = in.readInt();
                float[] pos = new float[nv * 3], nrm = new float[nv * 3], uv = new float[nv * 2];
                int[] idx = new int[nt * 3];
                for (int i = 0; i < pos.length; i++) pos[i] = in.readFloat();
                for (int i = 0; i < nrm.length; i++) nrm[i] = in.readByte() / 127f;
                for (int i = 0; i < uv.length; i++) uv[i] = in.readFloat();
                for (int i = 0; i < idx.length; i++) idx[i] = nv <= 65535 ? in.readUnsignedShort() : in.readInt();
                model.byMaterial.computeIfAbsent(mat, k -> new ArrayList<>()).add(new Piece(bone, mat, pos, nrm, uv, idx));
                model.maxVertices = Math.max(model.maxVertices, nv);
            }
        }
        for (List<Piece> list : model.byMaterial.values()) {
            for (Piece piece : list) {
                piece.offset = model.totalVertices;
                model.totalVertices += piece.vertices();
            }
        }
        readActions(model, data.getAsJsonObject("anims").getAsJsonObject(String.valueOf(stage)));
        return model;
    }

    private static void readActions(SusanooModel model, @Nullable JsonObject anims) {
        if (anims != null) {
            for (Map.Entry<String, JsonElement> e : anims.entrySet()) {
                JsonObject a = e.getValue().getAsJsonObject();
                if (e.getKey().equals("block")) {
                    model.blockPose = pose(a);
                    continue;
                }
                JsonArray keys = a.getAsJsonArray("keys");
                int[] times = new int[keys.size()];
                List<Map<String, float[]>> poses = new ArrayList<>();
                for (int k = 0; k < keys.size(); k++) {
                    JsonArray key = keys.get(k).getAsJsonArray();
                    times[k] = key.get(0).getAsInt();
                    poses.add(pose(key.get(1).getAsJsonObject()));
                }
                model.actions.put(e.getKey(), new Action(a.get("len").getAsInt(), times, poses));
            }
        }
    }

    private static Map<String, float[]> pose(JsonObject o) {
        Map<String, float[]> out = new HashMap<>();
        for (Map.Entry<String, JsonElement> b : o.entrySet()) {
            JsonArray r = b.getValue().getAsJsonArray();
            out.put(b.getKey(), new float[]{r.get(0).getAsFloat(), r.get(1).getAsFloat(), r.get(2).getAsFloat()});
        }
        return out;
    }
}
