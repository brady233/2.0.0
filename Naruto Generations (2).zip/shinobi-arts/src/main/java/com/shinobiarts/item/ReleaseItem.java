package com.shinobiarts.item;

import com.shinobiarts.client.ClientNinjaData;
import com.shinobiarts.jutsu.Jutsu;
import com.shinobiarts.ninja.ChakraNature;
import com.shinobiarts.ninja.NinjaData;
import net.minecraft.ChatFormatting;
import net.minecraft.network.chat.Component;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResultHolder;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.TooltipFlag;
import net.minecraft.world.level.Level;

import javax.annotation.Nullable;
import java.util.List;

/**
 * A release (held as its octagon emblem). Holding one (main hand or off hand) equips that release: the HUD shows its
 * jutsu slots, G/H move between them, and right-click casts the selected one. Jutsu that deal damage charge while
 * right-click is held (counter under the crosshair) and go off when it's released; see {@link com.shinobiarts.jutsu.JutsuCharge}.
 * Learning a jutsu from a scroll adds it to the slots of its release.
 */
public class ReleaseItem extends Item {
    private final ChakraNature release;

    public ReleaseItem(ChakraNature release, Properties properties) {
        super(properties);
        this.release = release;
    }

    public ChakraNature release() {
        return release;
    }

    /**
     * Right-click: a jutsu that deals damage starts charging (released in {@link #releaseUsing}); anything else is
     * cast straight away (the arm swings only if the jutsu goes off). Both sides decide from the same synced data.
     */
    @Override
    public InteractionResultHolder<ItemStack> use(Level level, Player player, InteractionHand hand) {
        ItemStack stack = player.getItemInHand(hand);
        Jutsu jutsu = selected(level, player);
        if (jutsu != null && com.shinobiarts.jutsu.JutsuCharge.held(jutsu)) {     // held: it lasts while right-click is down
            player.startUsingItem(hand);
            if (player instanceof net.minecraft.server.level.ServerPlayer sp) com.shinobiarts.jutsu.JutsuCaster.tryCast(sp, release, hand);
            return InteractionResultHolder.consume(stack);
        }
        if (jutsu != null && com.shinobiarts.jutsu.JutsuCharge.chargeable(jutsu)) {
            player.startUsingItem(hand);
            return InteractionResultHolder.consume(stack);
        }
        if (player instanceof net.minecraft.server.level.ServerPlayer sp) {
            com.shinobiarts.jutsu.JutsuCaster.tryCast(sp, release, hand);
        }
        return InteractionResultHolder.consume(stack);
    }

    /** The jutsu this release would cast, from the server's data or the client's synced copy. */
    @Nullable
    private Jutsu selected(Level level, Player player) {
        NinjaData d = level.isClientSide ? ClientNinjaData.get() : NinjaData.get(player);
        return d == null || !d.hasNature(release) ? null : d.selectedJutsu(release);
    }

    @Override
    public int getUseDuration(ItemStack stack) {
        return 72000;
    }

    @Override
    public net.minecraft.world.item.UseAnim getUseAnimation(ItemStack stack) {
        return net.minecraft.world.item.UseAnim.BOW;
    }

    /** Letting go of right-click casts the charged jutsu. */
    @Override
    public void releaseUsing(ItemStack stack, Level level, net.minecraft.world.entity.LivingEntity entity, int timeLeft) {
        if (entity instanceof net.minecraft.server.level.ServerPlayer sp) {
            if (com.shinobiarts.jutsu.WaterPrison.isHolding(sp)) {           // letting go of a held jutsu ends it
                com.shinobiarts.jutsu.WaterPrison.end(sp, false);
                return;
            }
            Jutsu jutsu = selected(level, sp);
            if (jutsu != null && com.shinobiarts.jutsu.JutsuCharge.held(jutsu)) return;
            int held = getUseDuration(stack) - timeLeft;
            com.shinobiarts.jutsu.JutsuCaster.castCharged(sp, release, sp.getUsedItemHand(), held);
        }
    }

    /** While charging: chakra gathers around the hands in the release's colour, and a chime marks a full charge. */
    @Override
    public void onUseTick(Level level, net.minecraft.world.entity.LivingEntity entity, ItemStack stack, int remaining) {
        if (!(level instanceof net.minecraft.server.level.ServerLevel server) || !(entity instanceof Player player)) return;
        Jutsu jutsu = selected(level, player);
        if (jutsu == null || com.shinobiarts.jutsu.JutsuCharge.held(jutsu)) return;
        int held = getUseDuration(stack) - remaining;
        int full = com.shinobiarts.jutsu.JutsuCharge.fullChargeTicks(jutsu);
        float frac = com.shinobiarts.jutsu.JutsuCharge.fraction(jutsu, held);
        int rgb = release.rgb();
        net.minecraft.core.particles.DustParticleOptions dust = new net.minecraft.core.particles.DustParticleOptions(
                new org.joml.Vector3f(((rgb >> 16) & 255) / 255f, ((rgb >> 8) & 255) / 255f, (rgb & 255) / 255f), 0.6f + frac * 0.9f);
        net.minecraft.world.phys.Vec3 hands = player.getEyePosition().add(player.getLookAngle().scale(0.7)).add(0, -0.45, 0);
        if (held % 2 == 0) {
            double r = 0.6 - frac * 0.4; // the chakra pulls in tighter as the charge builds
            server.sendParticles(dust, hands.x, hands.y, hands.z, 2 + Math.round(frac * 6), r, r, r, 0.0);
        }
        int top = full + com.shinobiarts.jutsu.JutsuCharge.overchargeTicks();
        if (held > full && held <= top && (held - full) % 10 == 0) {          // overcharging: the chakra swells
            float size = com.shinobiarts.jutsu.JutsuCharge.size(jutsu, held);
            server.sendParticles(dust, hands.x, hands.y, hands.z, 6, 0.3 * size, 0.3 * size, 0.3 * size, 0.0);
            level.playSound(null, player.getX(), player.getY(), player.getZ(), net.minecraft.sounds.SoundEvents.BEACON_AMBIENT,
                    net.minecraft.sounds.SoundSource.PLAYERS, 0.5f, 0.6f + 1.2f * (held - full) / (float) (top - full));
        }
        if (held == top) {
            level.playSound(null, player.getX(), player.getY(), player.getZ(), net.minecraft.sounds.SoundEvents.BEACON_POWER_SELECT,
                    net.minecraft.sounds.SoundSource.PLAYERS, 1.0f, 1.6f);
        }
        if (held == full) {
            server.sendParticles(net.minecraft.core.particles.ParticleTypes.FLASH, hands.x, hands.y, hands.z, 1, 0, 0, 0, 0);
            level.playSound(null, player.getX(), player.getY(), player.getZ(), net.minecraft.sounds.SoundEvents.AMETHYST_BLOCK_CHIME,
                    net.minecraft.sounds.SoundSource.PLAYERS, 1.2f, 1.4f);
        }
    }

    /** The release the player is currently holding (main hand first), or null. */
    @Nullable
    public static ChakraNature heldRelease(Player player) {
        for (InteractionHand hand : InteractionHand.values()) {
            if (player.getItemInHand(hand).getItem() instanceof ReleaseItem item) return item.release;
        }
        return null;
    }

    /** Gives the player this release's scroll (dropped at their feet if the inventory is full). */
    public static void give(net.minecraft.server.level.ServerPlayer player, ChakraNature release) {
        ItemStack stack = new ItemStack(com.shinobiarts.registry.ModItems.release(release));
        player.getInventory().add(stack);
        if (!stack.isEmpty()) player.drop(stack, false);
        player.sendSystemMessage(Component.translatable("message.shinobiarts.release_given", release.displayName()).withStyle(ChatFormatting.AQUA));
    }

    @Override
    public void appendHoverText(ItemStack stack, @Nullable Level level, List<Component> tooltip, TooltipFlag flag) {
        tooltip.add(Component.translatable("tooltip.shinobiarts.release_hold").withStyle(ChatFormatting.GRAY));
        if (release.isClanRelease() && release.clan() != null) {
            tooltip.add(Component.translatable("tooltip.shinobiarts.release_clan", release.clan().displayName()).withStyle(ChatFormatting.GRAY));
        }
        if (release.isAdvanced()) {
            ChakraNature[] parts = release.parts();
            tooltip.add(Component.translatable("tooltip.shinobiarts.release_advanced", parts[0].displayName(), parts[1].displayName())
                    .withStyle(ChatFormatting.GRAY));
        }
        if (level == null || !level.isClientSide) return;
        NinjaData d = ClientNinjaData.get();
        if (!d.hasNature(release)) {
            tooltip.add(Component.translatable(release.isAdvanced() ? "tooltip.shinobiarts.release_advanced_locked"
                    : release.isKekkeiGenkai() ? "tooltip.shinobiarts.release_clan_locked"
                    : "tooltip.shinobiarts.release_locked").withStyle(ChatFormatting.RED));
            return;
        }
        List<Jutsu> slots = d.slots(release);
        if (slots.isEmpty()) {
            tooltip.add(Component.translatable("tooltip.shinobiarts.release_empty").withStyle(ChatFormatting.DARK_GRAY));
        } else {
            for (Jutsu j : slots) tooltip.add(Component.literal(" - ").append(j.displayName()));
        }
    }
}
