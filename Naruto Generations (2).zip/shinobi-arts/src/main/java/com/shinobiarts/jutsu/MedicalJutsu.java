package com.shinobiarts.jutsu;

import com.shinobiarts.fx.Fx;
import com.shinobiarts.ninja.NinjaData;
import com.shinobiarts.ninja.Stat;
import com.shinobiarts.registry.ModDamage;
import com.shinobiarts.util.Scheduler;
import net.minecraft.ChatFormatting;
import net.minecraft.core.particles.DustParticleOptions;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.decoration.ArmorStand;
import net.minecraft.world.level.ClipContext;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.BlockHitResult;
import net.minecraft.world.phys.HitResult;
import net.minecraft.world.phys.Vec3;
import org.joml.Vector3f;

import javax.annotation.Nullable;
import java.util.Optional;

/**
 * Medical Release (Iryō Ninjutsu), everyone's release, learned from scrolls:
 * <ul>
 *   <li>Healing Jutsu (C): green chakra pours from your hands into the one you look at, healing them over two seconds
 *       and closing their wounds (Regeneration).</li>
 *   <li>Poison Mist (B, Shizune): you blow out a spreading cloud of violet poison that lingers for six seconds.</li>
 *   <li>Cellular Activation (A, Tsunade's Creation Rebirth): your cells divide at a furious rate; for fifteen seconds
 *       your wounds close almost as fast as they open and poisons, withering and slowness are burned out.</li>
 * </ul>
 * Healing grows with the Medical stat.
 */
public final class MedicalJutsu {
    private static final DustParticleOptions HEAL_DUST = new DustParticleOptions(new Vector3f(0.45f, 1.0f, 0.6f), 1.2f);
    private static final DustParticleOptions POISON_DUST = new DustParticleOptions(new Vector3f(0.55f, 0.2f, 0.75f), 2.2f);

    private MedicalJutsu() {}

    /** The creature or player you look at within {@code range}, friend or foe (not armor stands). */
    @Nullable
    private static LivingEntity patient(ServerPlayer p, double range) {
        Vec3 start = p.getEyePosition();
        Vec3 end = start.add(p.getLookAngle().scale(range));
        BlockHitResult wall = p.level().clip(new ClipContext(start, end, ClipContext.Block.COLLIDER, ClipContext.Fluid.NONE, p));
        if (wall.getType() != HitResult.Type.MISS) end = wall.getLocation();
        LivingEntity best = null;
        double bestDist = Double.MAX_VALUE;
        for (Entity e : p.level().getEntities(p, new AABB(start, end).inflate(1.0),
                c -> c instanceof LivingEntity l && l.isAlive() && !(c instanceof ArmorStand) && !c.isSpectator())) {
            Optional<Vec3> hit = e.getBoundingBox().inflate(0.4).clip(start, end);
            if (hit.isPresent() && start.distanceToSqr(hit.get()) < bestDist) {
                bestDist = start.distanceToSqr(hit.get());
                best = (LivingEntity) e;
            }
        }
        return best;
    }

    public static boolean healingJutsu(ServerPlayer p, NinjaData d) {
        LivingEntity patient = patient(p, 10);
        if (patient == null) {
            p.displayClientMessage(Component.translatable("message.shinobiarts.heal_no_target").withStyle(ChatFormatting.GRAY), true);
            return false;
        }
        if (patient.getHealth() >= patient.getMaxHealth() && patient.getActiveEffects().stream().noneMatch(e -> !e.getEffect().isBeneficial())) {
            p.displayClientMessage(Component.translatable("message.shinobiarts.full_health").withStyle(ChatFormatting.GRAY), true);
            return false;
        }
        ServerLevel level = p.serverLevel();
        float total = 12f + d.stat(Stat.MEDICAL) * 0.4f;
        Fx.on(level, Fx.Visual.HEAL, p, patient, 1f, 44);
        for (int k = 0; k < 4; k++) {                               // it flows in over two seconds
            final int pulse = k;
            Scheduler.later(4 + k * 10, () -> {
                if (!patient.isAlive() || !p.isAlive()) return;
                patient.heal(total / 4f);
                Vec3 c = patient.getBoundingBox().getCenter();
                level.sendParticles(HEAL_DUST, c.x, c.y, c.z, 14, patient.getBbWidth() * 0.5, patient.getBbHeight() * 0.35, patient.getBbWidth() * 0.5, 0.0);
                if (pulse == 3) {
                    patient.removeEffect(MobEffects.POISON);
                    patient.removeEffect(MobEffects.WITHER);
                    patient.addEffect(new MobEffectInstance(MobEffects.REGENERATION, 100, 1));
                    level.sendParticles(ParticleTypes.HEART, c.x, c.y + patient.getBbHeight() * 0.4, c.z, 4, 0.4, 0.2, 0.4, 0.0);
                }
            });
        }
        JutsuUtil.sound(level, patient.position(), SoundEvents.AMETHYST_BLOCK_RESONATE, 1.2f, 1.4f);
        JutsuUtil.sound(level, patient.position(), SoundEvents.BEACON_ACTIVATE, 0.5f, 1.8f);
        if (patient instanceof ServerPlayer other && other != p) {
            other.displayClientMessage(Component.translatable("message.shinobiarts.healed_by", p.getDisplayName()).withStyle(ChatFormatting.GREEN), true);
        }
        return true;
    }

    public static boolean poisonMist(ServerPlayer p, NinjaData d) {
        ServerLevel level = p.serverLevel();
        Vec3 look = p.getLookAngle();
        Vec3 flat = new Vec3(look.x, 0, look.z);
        flat = flat.lengthSqr() < 1e-4 ? new Vec3(0, 0, 1) : flat.normalize();
        // the cloud settles a few blocks ahead (bigger and further when overcharged)
        double ahead = 3.5 + 1.5 * JutsuUtil.size();
        Vec3 centre = p.position().add(flat.scale(ahead)).add(0, 1.0, 0);
        BlockHitResult wall = level.clip(new ClipContext(p.getEyePosition(), centre, ClipContext.Block.COLLIDER, ClipContext.Fluid.NONE, p));
        if (wall.getType() != HitResult.Type.MISS) centre = wall.getLocation().subtract(flat.scale(1.0));
        final Vec3 at = centre;
        final float radius = 4.5f;
        final float dps = JutsuUtil.dmg(2.5f);
        Fx.at(level, Fx.Visual.POISON_MIST, at, radius, 130);
        JutsuUtil.stream(level, POISON_DUST, p.getEyePosition().add(0, -0.2, 0), look, 18, 40, 0.3, 0.9);
        Scheduler.repeat(6, 10, 12, i -> {                         // six seconds of choking fog
            for (LivingEntity e : JutsuUtil.inRadius(level, p, at, radius)) {
                e.addEffect(new MobEffectInstance(MobEffects.POISON, 80, 1));
                e.addEffect(new MobEffectInstance(MobEffects.MOVEMENT_SLOWDOWN, 30, 1));
                if (i % 2 == 0) {
                    e.invulnerableTime = 0;
                    e.hurt(ModDamage.jutsu(level, p, p), dps);
                }
                if (i == 0) e.addEffect(new MobEffectInstance(MobEffects.CONFUSION, 120, 0));
            }
        });
        JutsuUtil.sound(level, p.position(), SoundEvents.ENDER_DRAGON_SHOOT, 0.8f, 0.6f);
        JutsuUtil.sound(level, at, SoundEvents.FIRE_EXTINGUISH, 1.0f, 0.5f);
        return true;
    }

    public static boolean cellularActivation(ServerPlayer p, NinjaData d) {
        ServerLevel level = p.serverLevel();
        int ticks = 300 + d.stat(Stat.MEDICAL) * 4;
        p.heal(6f + d.stat(Stat.MEDICAL) * 0.2f);
        p.addEffect(new MobEffectInstance(MobEffects.REGENERATION, ticks, 3));
        p.addEffect(new MobEffectInstance(MobEffects.DAMAGE_RESISTANCE, ticks, 0));
        for (var bad : new net.minecraft.world.effect.MobEffect[]{MobEffects.POISON, MobEffects.WITHER, MobEffects.MOVEMENT_SLOWDOWN,
                MobEffects.WEAKNESS, MobEffects.DIG_SLOWDOWN, MobEffects.CONFUSION, MobEffects.BLINDNESS, MobEffects.HUNGER}) {
            p.removeEffect(bad);
        }
        p.clearFire();
        Fx.on(level, Fx.Visual.CELL_ACTIVATION, p, null, 1f, ticks);
        Vec3 c = p.getBoundingBox().getCenter();
        level.sendParticles(HEAL_DUST, c.x, c.y, c.z, 60, 0.5, 0.9, 0.5, 0.0);
        JutsuUtil.sound(level, p.position(), SoundEvents.BEACON_POWER_SELECT, 1.0f, 1.5f);
        JutsuUtil.sound(level, p.position(), SoundEvents.WARDEN_HEARTBEAT, 1.2f, 1.6f);
        return true;
    }
}
